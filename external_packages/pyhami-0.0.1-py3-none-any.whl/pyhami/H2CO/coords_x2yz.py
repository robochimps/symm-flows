#Coordinates for tetraatomic molecule X2YZ. X2YZ: #e.g. H2CO
from jax import numpy as jnp
from pyhami.keo import com
from typing import List, Callable
from abc import ABC

import jax
jax.config.update("jax_enable_x64", True)

@com
def internal_to_cartesian(internal_coords):
    rCO, rCH1, rCH2, aOCH1, aOCH2, tau = internal_coords
    xyz =[[0.0, 0.0, 0.0],
          [0.0, 0.0, rCO],
          [rCH1 * jnp.sin(aOCH1) * jnp.cos(tau * 0.5), -rCH1 * jnp.sin(aOCH1) * jnp.sin(tau * 0.5), rCH1 * jnp.cos(aOCH1)],
          [rCH2 * jnp.sin(aOCH2) * jnp.cos(tau * 0.5), rCH2 * jnp.sin(aOCH2) * jnp.sin(tau * 0.5), rCH2 * jnp.cos(aOCH2)]]
    return jnp.array(xyz, dtype=jnp.float64)

def cartesian_to_internal(xyz_coords): #not coded yet
        r1, r2, a = xyz_coords
        return jnp.array([r1, r2, a])


