#Coordinates for tetraatomic molecule X3Y #e.g. NH3
from jax import numpy as jnp
from pyhami.keo import com
from typing import List, Callable
from abc import ABC

import jax
jax.config.update("jax_enable_x64", True)

@com
def internal_to_cartesian(internal_coords):
    r1, r2, r3, s4, s5, tau = internal_coords
    rho = tau + jnp.pi / 2

    beta1 = jnp.sqrt(6) / 3 * s4 + 2 * jnp.pi / 3
    beta2 = -1 / jnp.sqrt(6) * s4 + 1 / jnp.sqrt(2) * s5 + 2 * jnp.pi / 3
    beta3 = -1 / jnp.sqrt(6) * s4 - 1 / jnp.sqrt(2) * s5 + 2 * jnp.pi / 3

    cos_rho = jnp.cos(rho)
    sin_rho = jnp.sin(rho)
    cos_beta2 = jnp.cos(beta2)
    cos_beta3 = jnp.cos(beta3)
    sin_beta2 = jnp.sin(beta2)
    sin_beta3 = jnp.sin(beta3)

    xyz = jnp.array(
        [
            [0.0, 0.0, 0.0],
            [r1 * sin_rho, 0.0, r1 * cos_rho],
            [r2 * sin_rho * cos_beta3, r2 * sin_rho * sin_beta3, r2 * cos_rho],
            [r3 * sin_rho * cos_beta2, -r3 * sin_rho * sin_beta2, r3 * cos_rho],
        ]
    )
    return xyz

def cartesian_to_internal(xyz_coords): #not coded yet
        r1, r2, a = xyz_coords
        return jnp.array([r1, r2, a])


