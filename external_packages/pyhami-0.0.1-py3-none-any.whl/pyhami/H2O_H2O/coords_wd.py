"""Coordinate system for water dimer"""
import jax
import jax.numpy as jnp
from jax import config
from pyhami.keo import com, Molecule
config.update("jax_enable_x64", True)



@com
def internal_to_cartesian(internal_coords):
    masses = jnp.array([15.99491461956,1.00782503223,1.00782503223,15.99491461956,1.00782503223,1.00782503223])
    rB, rF, rA1, rA2, R, HOH_d, HOH_a, theta, beta, phi, alpha, gamma = internal_coords
    deg_to_rad = jnp.pi/180

    #Convert angles from degrees to radiance
    HOH_a,HOH_d,theta, beta, phi, alpha, gamma = HOH_a*deg_to_rad, HOH_d*deg_to_rad, theta*deg_to_rad, beta*deg_to_rad, phi*deg_to_rad, alpha*deg_to_rad, gamma*deg_to_rad

    #Define acceptor initial coordinates - , Oxygen = first column, Hf = second , etc.
    xyz_u1 = jnp.array([[0.0, 0.0, 0.0],
               [0.0, rA1 * jnp.sin(HOH_a / 2), -rA2 * jnp.sin(HOH_a / 2)],
               [0.0, rA1 * -jnp.cos(HOH_a / 2), -rA2 * jnp.cos(HOH_a / 2)]])

    # shift to centre of mass - acceptor unit
    cm1 = jnp.einsum('i,ji->j',masses[0:3], xyz_u1,optimize="optimal")
    #cm1 = jnp.dot(masses[0:3], xyz_u1) / jnp.sum(masses[0:3])
    xyz_u1 -= cm1[:,jnp.newaxis]/jnp.sum(masses[0:3])

    #Define donor initial coordinates, Oxygen = first column, Hf = second , etc.
    xyz_u2 = jnp.array([[0.0, 0.0, 0.0],
               [0.0, rF * jnp.sin(HOH_d / 2), -rB * jnp.sin(HOH_d / 2)],
               [0.0, -rF * jnp.cos(HOH_d / 2), -rB * jnp.cos(HOH_d / 2)]])

    # shift to centre of mass - donor unit
    cm2 = jnp.einsum('i,ji->j',masses[3:6],xyz_u2,optimize="optimal")
    xyz_u2 -= cm2[:,jnp.newaxis]/jnp.sum(masses[3:6])

    #Define and use Euler rotation matrix for acceptor in z-y-z convention
    rotmx1 = Euler_rot_mat(0.0,theta,phi)
    xyz_u1 = jnp.einsum('ij,jk->ik',rotmx1, xyz_u1,optimize="optimal")
    #xyz_u1 = jnp.dot(rotmx1, xyz_u1) # alternative code

    #Define and use Euler rotation matrix for donor in z-y-z convention
    rotmx2 = Euler_rot_mat(alpha,beta,gamma)
    xyz_u2 = jnp.einsum('ij,jk->ik',rotmx2, xyz_u2,optimize="optimal")
    xyz_u2 += jnp.array([[0],[0],[R]])
    return jnp.transpose(jnp.concatenate((xyz_u1,xyz_u2),axis=1))

def cartesian_to_internal(xyz_coords):
    masses = jnp.array([15.99491461956,1.00782503223,1.00782503223,15.99491461956,1.00782503223,1.00782503223])
    O1, H1, H2, O2, H3, H4 = xyz_coords
    ###Intra (not normalized vectors)###
    #Acceptor unit intra
    vA1 = H1 - O1
    vA2 = H2 - O1
    rA1 = jnp.linalg.norm(vA1)
    rA2 = jnp.linalg.norm(vA2)
    rad_to_deg = 180.0/jnp.pi
    HOH_a = jnp.arccos(jnp.dot(vA1, vA2) / (rA1 * rA2))*rad_to_deg

    #Donor unit intra
    vF = H3 - O2
    vB = H4 - O2
    rF = jnp.linalg.norm(vF)
    rB = jnp.linalg.norm(vB)
    rad_to_deg = 180.0/jnp.pi
    HOH_d = jnp.arccos(jnp.dot(vF, vB) / (rF * rB))*rad_to_deg

    ###Inter (normalized vectors)###
    #Inter - R
    CoM1 = jnp.einsum('i,ij->j',masses[0:3],xyz_coords[0:3,:],optimize="optimal")/jnp.sum(masses[0:3])
    CoM2 = jnp.einsum('i,ij->j',masses[3:6],xyz_coords[3:6,:],optimize="optimal")/jnp.sum(masses[3:6])
    vR = CoM2-CoM1 #Vector between CoMs
    R = jnp.linalg.norm(vR) #Distance between CoMs
    vR = vR/R #Normalize

    #Inter theta and beta from HOH bisector vectors and CoM vector
    vzA = -(vA1/rA1 + vA2/rA2) #HOH bisecting vector
    rzA = jnp.linalg.norm(vzA)
    vzA = vzA/rzA #Normalize

    vzD = vF/rF + vB/rB
    rzD = jnp.linalg.norm(vzD)
    vzD = vzD/rzD #Normalize

    theta = jnp.arccos(jnp.dot(vzA, vR))*rad_to_deg#*rad_to_deg

    beta = jnp.arccos(jnp.dot(vzD, -vR))*rad_to_deg#alternative

    #Alpha is define from donor acceptor RELATIVE orientation
    #First find monomer x-axes (parralel to Lab-axis for theta/beta = 0)
    vxA2 = vzA - jnp.dot(vzA,vR)*vR
    vxA2 = vxA2/jnp.linalg.norm(vxA2)

    vxD2 = vzD - jnp.dot(vzD,vR)*vR
    vxD2 = vxD2/jnp.linalg.norm(vxD2)
    alpha = jnp.sign(jnp.dot(jnp.cross(-vxA2,vxD2),vR))*jnp.arctan2(jnp.linalg.norm(jnp.cross(-vxA2,vxD2)), jnp.dot(-vxA2,vxD2))*rad_to_deg

    #Inter phi
    #x-axis is along laboratory X-axis for theta=0
    vxA = -jnp.cross(vA1/rA1,vA2/rA2)
    rxA = jnp.linalg.norm(vxA)
    vxA = vxA/rxA

    #y-axis is along laboratory Y-axis for theta=0
    vyA = jnp.cross(vzA,vxA)
    ryA = jnp.linalg.norm(vyA)
    vyA = vyA/ryA

    phi = -jnp.arctan2(jnp.dot(-vyA,vR),jnp.dot(-vxA,vR))*rad_to_deg

    #Inter gamma
    #x-axis is along laboratory X-axis for beta=0
    vxD = -jnp.cross(vF/rF,vB/rB)
    rxD = jnp.linalg.norm(vxD)
    vxD = vxD/rxD

    #y-axis is along laboratory Y-axis for beta=0
    vyD = jnp.cross(vzD,vxD)
    ryD = jnp.linalg.norm(vyD)
    vyD = vyD/ryD

    gamma = jnp.arctan2(jnp.dot(-vyD,vR),jnp.dot(-vxD,vR))*rad_to_deg
    return jnp.array([rB, rF, rA1, rA2, R, HOH_d, HOH_a, theta, beta, phi, alpha, gamma])


def Euler_rot_mat(a1,a2,a3):
    #Euler rotation of acceptor in z-y-z convention
    cal = jnp.cos(a1)
    sal = jnp.sin(a1)
    cbe = jnp.cos(a2);
    sbe = jnp.sin(a2);
    cga = jnp.cos(a3);
    sga = jnp.sin(a3);
    #Return Euler rotation in z-y-z convention
    return jnp.array([[cga*cbe*cal-sga*sal, -sga*cbe*cal-cga*sal, sbe*cal],
                           [cga*cbe*sal+sga*cal, -sga*cbe*sal+cga*cal, sbe*sal],
                           [-cga*sbe, sga*sbe, cbe]])
