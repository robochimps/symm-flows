import os
os.environ["JAX_PLATFORMS"] = "cpu"

import jax
import jax.numpy as jnp
import numpy as np

from functools import partial
from scipy import optimize
from jax import config
from pyhami.H2O_H2O.water_dimer_MBpol import potential as potential_f2py
from pyhami.H2O_H2O.water_dimer_MBpol_1 import potential as potential_pybind11
from pyhami.H2O_H2O.coords_wd import internal_to_cartesian, cartesian_to_internal
from pyhami.keo import Molecule

config.update("jax_enable_x64", True)

# Wrapper for potential that avoids JAX compilation
def potential_no_jit(xyz):
     #jax.pure_callback ensures the function runs on the host (i.e., not compiled)
    result_shape = jax.ShapeDtypeStruct((), jnp.float64)
    return jax.pure_callback(potential_pybind11, result_shape, xyz)

@jax.custom_jvp
def pot(internal_coords):
    """
        Evaluation of the potential in internal coordinates:
        {rB, rF, rA1, rA2, R, HOH_d, HOH_a, theta, beta, phi, alpha, gamma}
    """
    # Go to euclidian coordinates
    xyz_molecule = Molecule.internal_to_cartesian(internal_coords)
    xyz = jnp.ravel(xyz_molecule).astype(jnp.float64) 
    # Return evaluated potential. Reshape because potential expects shape (18,) instead of (6,3)
    return potential_no_jit(xyz)

@pot.defjvp
def pot_jvp(primals, tangents):
    """
        Derivative of the potential function with JAX
    """
    internal_coords = primals[0]
    internal_dot = tangents[0]
    primal_out = pot(internal_coords)
    tangent_out = jnp.dot(finite_difference(internal_coords), internal_dot)
    return primal_out, tangent_out

def finite_difference(coords, k = 12, step = 1e-4):
    """
        Derivative of the potential function by finite differences.
    """
    M = jnp.zeros((k, 4, k))
    M = M.at[:].set(coords) #M[:] = internal_coord
    
    h = jnp.eye(k, k)*step
    H = jnp.repeat(h[:, jnp.newaxis, :], 4, axis = 1)
    
    s = jnp.array([-2., -1., 1., 2.])
    S = H*s[:, jnp.newaxis]
    
    points = M + S
    coeff = jnp.array([1., -8., 8., -1.])
    FD = jnp.zeros(k)
    for i in range(k):
        e = []
        for j in range(4):
            e.append(pot(points[i, j]))
        e = jnp.array(e)*coeff
        FD = FD.at[i].set(jnp.sum(e)*(1/(12*step))) #E[i] = jnp.sum(e)
    
    return FD

def grad_descent_potential(coords, eta = 0.0075, tol = 1e-6): #eta = 0.0075, tol = 1e-6 
    """
        Check the implementing of the finite differences with gradient descent for find 
        the point of minimun potential (-1734.69 cm-1) in the potential surface energy
    """
    
    dif = 1
    k = 1
    D = []
    D.append(pot(coords))
    while dif >= tol:
        if k % 100 == 0:
            print(f'Iteration: {k}')
            print(f'Steps differences {dif}')
        grad = finite_difference(coords)
        coords -= eta*(grad/jnp.linalg.norm(grad))
        D.append(pot(coords))
        dif = jnp.abs(D[k]-D[k-1])
        k += 1
    print(f'Finish!')
    return coords, potential(coords)

if __name__ == "__main__":
    
    masses = jnp.array([15.99491461956, 1.00782503223, 1.00782503223, 15.99491461956, 1.00782503223, 1.00782503223])
    
    Molecule.masses = masses
    Molecule.internal_to_cartesian = internal_to_cartesian
    Molecule.cartesian_to_internal = cartesian_to_internal
    
    xyz_p = jnp.array([ [-1.516074336e+00,  -2.023167650e-01,   1.454672917e+00],
                        [-6.218989773e-01,  -6.009430735e-01,   1.572437625e+00],
                        [-2.017613812e+00,  -4.190350349e-01,   2.239642849e+00],
                        [-1.763651687e+00,  -3.816594649e-01,  -1.300353949e+00],
                        [-1.903851736e+00,  -4.935677617e-01,  -3.457810126e-01],
                        [-2.527904158e+00,  -7.613550077e-01,  -1.733803676e+00]], 
                        dtype = jnp.float64)
    
    
    r_p = cartesian_to_internal(xyz_p)
    
#    coords_min, potential_min = grad_descent_potential(r_p)

#    print(f'Potential minimun V(kcal/mol): {potential_min}')
#    print(f'Potential minimun V(cm-1): {potential_min*349.755}')
#    print(f'Internal coords: {coords_min}')
    
    print(f"Derivate with finite difference")
    print(finite_difference(r_p))
    print(f"Derivate with jax")
    print(jax.jacrev(pot)(r_p))
    print(f"Derivate optimizate with jax.jit")
    print(jax.jit(jax.jacrev(pot))(r_p))
# 
#    v = []
#    for i in range(100):
#        xyz = np.random.uniform(-4, 4, 18).reshape(6,3)
#        v.append(jnp.array(cartesian_to_internal(xyz)))
#    v = jnp.array(v)
#    print(v.shape)
#    a = jax.vmap(jax.jacrev(pot), 0)(v)
#    print(a.shape)
#    print(type(pot(r_p)))
#    print(jax.grad(pot)(r_p))
    
""" 
    print(jax.vmap(jax.jacrev(pot), 0)(r_p))
    xyz = jnp.ravel(xyz_p)
    print(potential(xyz))
    v = []
    for i in range(100):
        xyz = np.random.uniform(-4, 4, 18).reshape(6,3)
        v.append(jnp.array(cartesian_to_internal(xyz)))
        #print(pot(v[i]))
    v = jnp.array(v)
    print(jnp.ravel(potential(xyz_p)))
    print(jax.jacrev(pot)(r_p) == finite_difference(r_p))
    print(jax.jit(jax.jacrev(pot))(r_p).shape)
     r_p = jnp.array(np.random.random((50,12)))
    print(jax.vmap(jax.jacrev(pot), 0)(v))
    
    coords_min, potential_min = grad_descent_potential(r_p)

    print(f'Potential minimun V(kcal/mol): {potential_min}')
    print(f'Potential minimun V(cm-1): {potential_min*349.755}')
    print(f'Internal coords: {coords_min}')
"""   