from pyhami.H2O_H2O.water_dimer_MBpol import potential as potential_f2py
from pyhami.H2O_H2O.water_dimer_MBpol_1 import potential as potential_pybind11
import numpy as np

if __name__ == "__main__":
    
    Cart = np.array([-1.516074336e+00,  -2.023167650e-01,   1.454672917e+00,
                     -6.218989773e-01,  -6.009430735e-01,   1.572437625e+00,
                     -2.017613812e+00,  -4.190350349e-01,   2.239642849e+00,
                     -1.763651687e+00,  -3.816594649e-01,  -1.300353949e+00,
                     -1.903851736e+00,  -4.935677617e-01,  -3.457810126e-01,
                     -2.527904158e+00,  -7.613550077e-01,  -1.733803676e+00], dtype = np.float64)

    N = len(Cart)

    Vpot_f2py = []
    Vpot_pybind11 = []
    for i in range(10):
        if i > 0:
            Cart[i] -= 0.1
        Vpot_f2py.append(potential_f2py(Cart, N))
        Vpot_pybind11.append(potential_pybind11(Cart))
    
    Vpot_f2py = np.array(Vpot_f2py)
    Vpot_pybind11 = np.array(Vpot_pybind11)
    # Expected results from Fortran.
    Vpot_fortran = np.array([-3.3453214172534764, -3.2666881007263573, -1.0006304703564410,
                              4.4126027409514110,  0.7134162599283602,  1.7990103907639732,
                              6.5880972449820820,  7.8052021733600940,  1.3469573868656717,
                              6.1576145567976460], dtype = np.float64)

    print('Error of calculation on 10 points with the wrapper f2py', Vpot_fortran -  Vpot_f2py)
    print('Error of calculation on 10 points with the wrapper pybind11', Vpot_fortran -  Vpot_pybind11)
    