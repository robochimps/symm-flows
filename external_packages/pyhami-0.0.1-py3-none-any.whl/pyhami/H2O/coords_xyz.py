#Coordinates for XYZ-molecule. XYZ: #e.g. H2O, H2S, OCS, ...
from jax import numpy as jnp
from pyhami.keo import com
import jax
jax.config.update("jax_enable_x64", True)

@com
def internal_to_cartesian(internal_coords):
    r1, r2, a = internal_coords
    return jnp.array(
        [
            [0.0, 0.0, 0.0],
            [r1 * jnp.cos(a / 2), 0.0, r1 * jnp.sin(a / 2)],
            [r2 * jnp.cos(a / 2), 0.0, -r2 * jnp.sin(a / 2)],
        ])

def cartesian_to_internal(xyz_coords):
    xA, xB, xC = xyz_coords
    v1 = xA - xB
    v2 = xA - xC
    r1 = jnp.linalg.norm(v1)
    r2 = jnp.linalg.norm(v2)
    a = jnp.arccos(jnp.dot(v1, v2) / (r1 * r2))
    return jnp.array([r1, r2, a])
