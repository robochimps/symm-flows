from enum import Enum
import numpy as np

class Atom(Enum):
    H = "H"
    S = "S"
    C = "C"
    O = "O"

def molecular_masses(molecule):
    masses = []
    for atom in molecule:
        if atom == Atom.H:
            masses.append(1.00782503223)
        elif atom == Atom.S:
            masses.append(32.9714589099)
        elif atom == Atom.C:
            masses.append(12.0)
        elif atom == Atom.O:
            masses.append(15.99491461956) #might want to change this
    return np.array(masses)


