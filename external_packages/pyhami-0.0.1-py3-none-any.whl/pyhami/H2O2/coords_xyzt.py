#Coordinates for tetraatomic molecule XYZT. XYZT: #e.g. H2O2
from jax import numpy as jnp
from pyhami.keo import com
from typing import List, Callable
from abc import ABC

import jax
jax.config.update("jax_enable_x64", True)

@com
def internal_to_cartesian(internal_coords):
    rOO, rOH1, rOH2, aHOO1, aHOO2, tau = internal_coords
    xyz=[[0.0, 0.0, 0.0],
         [0.0, 0.0, rOO],
         [rOH1 * jnp.sin(aHOO1) * jnp.cos(tau * 0.5) , rOH1 * jnp.sin(tau * 0.5) * jnp.sin(aHOO1) , rOH1 * jnp.cos(aHOO1)],
         [rOH2 * jnp.sin(aHOO2) * jnp.cos(tau * 0.5), rOH2 * jnp.sin(-tau * 0.5) * jnp.sin(aHOO2), rOO - rOH2 * jnp.cos(aHOO2)]]
    return jnp.array(xyz, dtype=jnp.float64)

def cartesian_to_internal(xyz_coords): #not coded yet
        r1, r2, a = xyz_coords
        return jnp.array([r1, r2, a])

