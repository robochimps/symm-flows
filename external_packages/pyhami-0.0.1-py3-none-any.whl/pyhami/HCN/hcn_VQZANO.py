"""Implementation of the `VQZANO+.f90` Fortran function for computing
the potential energy surface of HCN molecule.

Main function:
    `v = potv(q)`

Parameters:
    q : ndarray
        A 2D array where each row represents a set of molecular coordinates
        specified as (r, R, cos(gamma)).
        - r (float): the CN bond length [Aangstroem].
        - R (float): the distance [Aangstroem] from the H atom to the center of mass of the CN moiety.
        - gamma (float): angle gamma between r and R.

The angle gamma varies from 0 to Pi radians.
A gamma value of 0 corresponds to a linear configuration of the HCN molecule.
A gamma value of Pi indicates the CNH configuration.
"""
import jax
import jax.numpy as jnp
from jax import config
config.update("jax_enable_x64", True)

def _legval(x, l):
    c = jnp.zeros(l+1)
    c = c.at[l].set(1.0)
    def iter(carry, cc):
        c0, c1, nd = carry
        tmp = c0
        nd = nd - 1
        c0 = cc - (c1*(nd - 1))/nd
        c1 = tmp + (c1*x*(2*nd - 1))/nd
        return (c0, c1, nd), 0
    c = c.reshape(c.shape + (1,)*x.ndim)
    if len(c) == 1:
        c0 = c[0]
        c1 = 0
    elif len(c) == 2:
        c0 = c[0]
        c1 = c[1]
    else:
        nd = len(c)
        c0 = c[-2]
        c1 = c[-1]
        # use scan instead of the loop below
        carry, _ = jax.lax.scan(iter, (c0, c1, nd), jnp.flip(c, axis=0)[2:])
        c0, c1, nd = carry
    return c0 + c1*x


def _rmorsecoord(R, beta, requalib, n):
    ratio = -beta * ((R - requalib) / requalib)
    temp = (1 - jnp.exp(ratio))
    rmor = temp**n
    return rmor


def _DBOC_corr(smallr, bigR, cosgamma):

    EH = 219474.624

    coeff = jnp.array([
        61300.7135899,
        895.886162423,
        -70565.8990549,
        4773.9817209,
        8856.65590136,
        -80797.3926551,
        -1682.1616785,
        92565.9091745,
        -5602.42892746,
        -9198.09369058,
        35939.9687435,
        929.150781931,
        -40169.8574301,
        2130.09338513,
        2704.67838662,
        -5313.95221068,
        -157.566257215,
        5780.36035164,
        -260.350322598,
        -167.44015843,
        -55370.316994,
        4754.39164204,
        83030.3122802,
        -8281.26766355,
        -26969.0665816,
        74094.2408883,
        -5925.76456913,
        -110370.495912,
        10527.0804951,
        34834.6549419,
        -33001.6947725,
        2471.70897939,
        48649.3467107,
        -4437.80010694,
        -14790.4934647,
        4887.37761221,
        -345.374981145,
        -7117.25664686,
        620.415816354,
        2062.69994319,
        12554.0937029,
        -1936.70511436,
        -21736.5239009,
        2472.52194725,
        9092.30843229,
        -16808.5214793,
        2498.58479994,
        29077.903879,
        -3205.61349595,
        -12071.3921973,
        7489.67926539,
        -1077.32941536,
        -12914.6546977,
        1383.34822742,
        5304.19453882,
        -1109.80874249,
        155.135287705,
        1905.01555022,
        -198.680122409,
        -771.435653363
    ])

    pot = -840.6019631  # averge value of correction

    ijk = [(i, j, k) for i in range(3) for j in range(4) for k in range(5)]
    def bigmorse(i): return bigR**i
    def smallmorse(j): return smallr**j
    def apolynom(k): return cosgamma**k

    pot += jnp.sum(jnp.array([coeff[l] * bigmorse(i) * smallmorse(j) * apolynom(k)
                              for l, (i, j, k) in enumerate(ijk)]))

    pot = pot / EH  # CONVERT FORM CM-1 TO HARTREE

    return pot


def _rel_corr(smallr, bigR, cosgamma):

    coeff = jnp.array([
        -0.0805585205815292,
        0.0950673303720766,
        -0.253364906126069,
        -0.084129451710227,
        -0.0745419772100667,
        0.0477227356064123,
        -0.130026022694324,
        0.335629886457965,
        0.107905706720457,
        0.0993733461559782,
        -0.0237612599129882,
        0.0595297964464055,
        -0.149509867823676,
        -0.0460734392042994,
        -0.0439643487346239,
        0.00388436986158473,
        -0.00906898001283882,
        0.0221602015192701,
        0.0065691932071385,
        0.00645621168784551,
        0.0266090487964399,
        -0.115552391578968,
        0.252922948126617,
        0.0870075200551087,
        0.0506809331899964,
        -0.041492313771614,
        0.156584563160005,
        -0.332335667002259,
        -0.111669707104665,
        -0.06770235689405,
        0.0220056679462455,
        -0.0710958741686161,
        0.146735654274853,
        0.047768960584727,
        0.0298863818957252,
        -0.00375993578145236,
        0.0107485671294735,
        -0.021583118481192,
        -0.00682587066702194,
        -0.00437935957298068,
        -0.0131085901581377,
        0.0460835147852451,
        -0.0826635630451006,
        -0.0312833158935659,
        -0.00904915849992159,
        0.0193658221974871,
        -0.0618956123071639,
        0.107774673538991,
        0.040184308696244,
        0.0123015451000135,
        -0.00973451656341789,
        0.0278651342014908,
        -0.0471541574047327,
        -0.0172250650594388,
        -0.00546984649469844,
        0.001602231058765,
        -0.00418032677019256,
        0.00687897584843289,
        0.00246635113824095,
        0.000805450828032454,
        0.00229338173792963,
        -0.00610190383854349,
        0.00863846660156985,
        0.00393643841031911,
        0.000202814342030121,
        -0.00323246774517316,
        0.00812760212687042,
        -0.011178025856714,
        -0.00505844398525825,
        -0.000330146921869386,
        0.00154631457145571,
        -0.0036279978431523,
        0.00484658611284714,
        0.00217108938922934,
        0.000160901000351014,
        -0.000244921320434022,
        0.000539999643014766,
        -0.000700947801549237,
        -0.000311210335395826,
        -2.53086031415751e-5
    ])

    pot = 0.0472411971073
    ijk = [(i, j, k) for i in range(4) for j in range(4) for k in range(5)]
    def bigmorse(i): return bigR**i
    def smallmorse(j): return smallr**j
    def apolynom(k): return cosgamma**k

    pot += jnp.sum(jnp.array([coeff[l] * bigmorse(i) * smallmorse(j) * apolynom(k)
                              for l, (i, j, k) in enumerate(ijk)]))

    return pot


def _potv(coords):

    smallr, bigR, gamma = coords
    smallr = smallr*1.8897261246257702
    bigR = bigR*1.8897261246257702
    
    coeff = jnp.array([
 0.1494042105E+00,
 0.2179006487E+00,
-0.3273920417E+00,
 0.8351497054E+00,
-0.6619144082E+00,
 0.4599713087E+00,
-0.2738662958E+00,
-0.4440119743E+01,
 0.1109277630E+02,
-0.1395244884E+02,
 0.1101296234E+02,
-0.7263133526E+01,
 0.2224483967E+01,
-0.5673184395E+00,
-0.1196408272E+02,
 0.3286537933E+02,
-0.3404040527E+02,
 0.2647031593E+02,
-0.1024488163E+02,
 0.4328814983E+01,
 0.6302400827E+00,
-0.1281658459E+02,
 0.3501254654E+02,
-0.2787051392E+02,
 0.2416838074E+02,
-0.3077708721E+01,
 0.2183263779E+01,
 0.2461140633E+01,
-0.5094871998E+01,
 0.1759796333E+02,
-0.7992774963E+01,
 0.1048842525E+02,
 0.2663014174E+01,
 0.9967646599E+00,
 0.2099469662E+01,
-0.7037402391E+00,
 0.3279056072E+01,
-0.3060762286E+00,
 0.1875680566E+01,
 0.9339466095E+00,
 0.2784251571E+00,
 0.6579222083E+00,
 0.4796701431E+01,
-0.1318006039E+02,
 0.1348409176E+02,
-0.1195808506E+02,
 0.6425770760E+01,
-0.2491237164E+01,
 0.6074722409E+00,
-0.7898491383E+01,
 0.2515898132E+02,
-0.2228882599E+02,
 0.2319293022E+02,
-0.7300096512E+01,
 0.4186582088E+01,
 0.1468366385E+01,
-0.5053308105E+02,
 0.1144061890E+03,
-0.1330410309E+03,
 0.8062403107E+02,
-0.4143428802E+02,
 0.5329541683E+01,
-0.1057870984E+01,
-0.6028519058E+02,
 0.1080324249E+03,
-0.1445681915E+03,
 0.5222629547E+02,
-0.3854883575E+02,
-0.6430528164E+01,
-0.2470804155E+00,
-0.2972009659E+02,
 0.2486521339E+02,
-0.6844873810E+02,
-0.2519468404E-01,
-0.2420088196E+02,
-0.9852017403E+01,
 0.1558390141E+01,
-0.5004767895E+01,
-0.3438580275E+01,
-0.1220398617E+02,
-0.2258141041E+01,
-0.8132832527E+01,
-0.3991177797E+01,
 0.1252798915E+01,
 0.2080360413E+02,
-0.4752796173E+02,
 0.6023006439E+02,
-0.4397934341E+02,
 0.2710381699E+02,
-0.9402210236E+01,
 0.3134345770E+01,
-0.1111633492E+02,
 0.1177921772E+02,
-0.3666366196E+02,
 0.1091868973E+02,
-0.2032316589E+02,
-0.1134070456E+00,
-0.3911679745E+01,
-0.1083814926E+03,
 0.2490106964E+03,
-0.2849703674E+03,
 0.1854083252E+03,
-0.1098742905E+03,
 0.3372972488E+02,
-0.1911353683E+02,
-0.9813106537E+02,
 0.2571860962E+03,
-0.2505248108E+03,
 0.1899570007E+03,
-0.1025988770E+03,
 0.2444090652E+02,
-0.2244192505E+02,
-0.4234691143E+01,
 0.8552397156E+02,
-0.4999621201E+02,
 0.1141592178E+03,
-0.4533333969E+02,
-0.1452669501E+01,
-0.1024097919E+02,
 0.1400469303E+02,
 0.2283895761E+00,
 0.5921393037E+00,
 0.3907504272E+02,
-0.9498566628E+01,
-0.6402152061E+01,
-0.4512357712E+00,
 0.1556770229E+02,
-0.4285261154E+02,
 0.3758481216E+02,
-0.2836553383E+02,
 0.5195811749E+01,
-0.2380146027E+01,
-0.2525846958E+01,
-0.6172574234E+02,
 0.1954359741E+03,
-0.1905524139E+03,
 0.1957860260E+03,
-0.9298155975E+02,
 0.5106489563E+02,
-0.1235393524E+02,
-0.2260525818E+03,
 0.6543347168E+03,
-0.5629700317E+03,
 0.5343278198E+03,
-0.2099469452E+03,
 0.1321243896E+03,
-0.1978376007E+02,
-0.1678566437E+03,
 0.5674368286E+03,
-0.4264934082E+03,
 0.5247149048E+03,
-0.1254009094E+03,
 0.1368169861E+03,
-0.1946393394E+02,
 0.6929652691E+01,
 0.1203537521E+03,
-0.1582188873E+03,
 0.2871345215E+03,
-0.1572170830E+02,
 0.5963705826E+02,
-0.9650691986E+01,
 0.3750868607E+02,
-0.1728201675E+02,
-0.4348765564E+02,
 0.8167091370E+02,
 0.7986162663E+01,
 0.3591517687E+01,
-0.1310849667E+01,
-0.8493385315E+01,
 0.2844993019E+02,
-0.3800553131E+02,
 0.4474219894E+02,
-0.2850215530E+02,
 0.1646527290E+02,
-0.3970207691E+01,
-0.1542687836E+03,
 0.3372832642E+03,
-0.4464781494E+03,
 0.2951505432E+03,
-0.1816697998E+03,
 0.5316984558E+02,
-0.6686333179E+01,
-0.3925593567E+03,
 0.6971489258E+03,
-0.9502923584E+03,
 0.4538467407E+03,
-0.3279503174E+03,
 0.6674200439E+02,
-0.5604239941E+01,
-0.3418550720E+03,
 0.4356850586E+03,
-0.8969200439E+03,
 0.2099159241E+03,
-0.2829770813E+03,
 0.5536326981E+02,
-0.5499388218E+01,
-0.6700291443E+02,
 0.1543539429E+02,
-0.4875061340E+03,
 0.2664015007E+02,
-0.1126098557E+03,
 0.2384203148E+02,
-0.3890762568E+01,
 0.2440213394E+02,
-0.5005599213E+02,
-0.1430028381E+03,
 0.8150361061E+01,
-0.6253750801E+01,
 0.1309172034E+01,
-0.1360354185E+01,
-0.1142237091E+02,
 0.3025738716E+02,
-0.3869804764E+02,
 0.3254767227E+02,
-0.1961404419E+02,
 0.7705432892E+01,
-0.2599303424E+00,
-0.7386426544E+02,
 0.2132664490E+03,
-0.1990179596E+03,
 0.1671524963E+03,
-0.6041564560E+02,
 0.1448185158E+02,
 0.1541442037E+01,
-0.1405283356E+03,
 0.4659133911E+03,
-0.2857222900E+03,
 0.2609895935E+03,
-0.6865476227E+02,
 0.1467753887E+02,
 0.5323611736E+01,
-0.6710372162E+02,
 0.4675559082E+03,
-0.1301919403E+03,
 0.1887061920E+03,
-0.4263847733E+02,
 0.1578407860E+02,
 0.6043389320E+01,
 0.4931479263E+02,
 0.2340046234E+03,
-0.2837063980E+02,
 0.7166375732E+02,
-0.9170268059E+01,
 0.9936111450E+01,
 0.2666974306E+01,
 0.4050671005E+02,
 0.5192458344E+02,
-0.1643330765E+02,
 0.1117124939E+02,
 0.3955295801E+01,
 0.1787165642E+01,
 0.7089445740E-01
    ])

    bigReC = jnp.array([
        3.3088409915851508813,
        -2.4563416322017199711,
        -1.0989512458800640982,
        0.8804973060435498100])

    BbigRC = jnp.array([
        0.83389452953072795705,
        -0.063550404733614548891,
        0.28431597260435503838])

    smallreC = jnp.array([
        2.2535051699746539988,
        -0.89102535433330598558,
        2.228022014935958417])

    BsmallrC = jnp.array([1.6606332738405520377])
    pot = 0.0
    icoefref = 1

    # Least Energy Isomerisation PATH COEFFICENTS

    R_co = jnp.array([
        2.06021279535746,
        0.206149293036705,
        1.38850960996447,
        -0.0678082821258994,
        -0.412935160444408])

    # HNC R MOPRHING COEFFIECNTS

    m_co = jnp.array([
        -0.000303673553151895,
        0.00435465925587477,
        0.00402462914869603,
        0.0139187573949336,
        0.0416697727891190,
        0.0264801392783952,
        -0.0216034082004957,
        -0.0493168970474053,
        -0.0297172762227854])

    #gamma = jnp.arccos(xgamma)

    # CRITCIAL POINT COORDINATE REMAPPING.

    sr = smallr + 0.001635 + \
        (0.0018646949949 * ((jnp.sin(gamma) + (0.131325005 * jnp.sin(gamma * 2.0)))**4))

    bR = bigR + 0.002205 - \
        (0.014287178436 * ((jnp.sin(gamma) + (0.131325005 * jnp.sin(gamma * 2.0)))**4))

    gamma = gamma + (0.0105990601023 * ((jnp.sin(gamma)
                     + (0.131325005 * jnp.sin(gamma * 2.0)))**16))

    cosgamma = jnp.cos(gamma)

    # BEGIN HNC R MORPHING

    Rmin = jnp.sum(jnp.array([R_co[j] * (cosgamma**j) for j in range(5)]))

    tempR = bR - Rmin
    shift1 = jnp.sum(jnp.array([m_co[j + (i * 3)] * tempR**i * cosgamma
                                ** j for i in range(3) for j in range(3)]))

    bR = bR + (shift1 * jnp.exp(-((0.6 * (jnp.arccos(cosgamma) - 3.1415927))**6)))

    # NEXT THE MAIN FIT CALCULATION

    rLEbigR = bigReC[0] + (bigReC[1] * cosgamma) + (bigReC[2]
                                                    * cosgamma * cosgamma) + (bigReC[3] * cosgamma * cosgamma * sr)

    rLEsmallr = smallreC[0] + (smallreC[1] * cosgamma) + \
        (smallreC[2] * cosgamma * cosgamma)

    betabigR = BbigRC[0] + (BbigRC[1] * cosgamma) + \
        (BbigRC[2] * cosgamma * cosgamma)

    betasmallr = BsmallrC[0]

    ijk = [(i, j, k) for i in range(6) for j in range(6) for k in range(7)]
    def bigmorse(i): return _rmorsecoord(bR, betabigR, rLEbigR, i)
    def smallmorse(j): return _rmorsecoord(sr, betasmallr, rLEsmallr, j)
    def apolynom(k): return _legval(cosgamma, k) #_plgndr(k, 0, cosgamma)
    pot += jnp.sum(jnp.array([coeff[l] * bigmorse(i) * smallmorse(j) * apolynom(k)
                              for l, (i, j, k) in enumerate(ijk)]))

    # CRITICAL POINT ENERGY SCALING NEXT

    pot = pot + ((-1.2381427e-7 * (jnp.arctan(15.0 * (gamma - 1.2)) + 1.5708))
                 + (1.2115228e-04 * ((jnp.sin(gamma) + (0.131325005 * jnp.sin(gamma * 2)))**16)))

    # lower limits to potential (hole patches)

    # general low R patch
    pot = jnp.where(bigR <= 1.0, jnp.ones_like(pot) * 100, pot)

    # Patch for irritating holes at higher low R
    aprxRbig = 2.113058664103 + \
        (cosgamma * 0.1544661511693) + (cosgamma * cosgamma * 0.9706585547594)

    pot = jnp.where(cosgamma <= 0.969, jnp.where(cosgamma > 0.071, jnp.where(
        bigR <= (aprxRbig - 0.8), jnp.ones_like(pot) * 100, pot), pot), pot)

    # pot = jax.lax.cond(cosgamma <= 0.969 and cosgamma > 0.071, lambda: jax.lax.cond(
    #     bigR <= (aprxRbig - 0.8), lambda: 100.0, lambda: pot), lambda: pot)

    # small r patch
    pot = jnp.where(smallr <= 1.7, jnp.ones_like(pot) * 100.0, pot)

    # patch for large smallr
    pot = jnp.where(smallr >= 3.5, jnp.ones_like(pot) * 100.0, pot)

    # patch for large R
    # general upper limit
    pot = jnp.where(bigR >= 7.0, jnp.ones_like(pot) * 100.0, pot)

    # angular conditions upper limit patchs

    pot = jnp.where(bigR >= 6.5, jnp.where(
        cosgamma <= 0.35, jnp.ones_like(pot) * 100, pot), pot)

    pot = jnp.where(bigR >= 6.0, jnp.where(
        cosgamma <= 0.3, jnp.ones_like(pot) * 100, pot), pot)

    pot = jnp.where(bigR >= 5.5, jnp.where(
        cosgamma <= 0.23173, jnp.ones_like(pot) * 100, pot), pot)

    pot = jnp.where(bigR >= 5.0, jnp.where(
        cosgamma <= 0.12945, jnp.ones_like(pot), pot), pot)

    pot = jnp.where(bigR >= 4.8, jnp.where(
        cosgamma <= -0.12944, jnp.ones_like(pot) * 100, pot), pot)

    pot = pot - 4.250289e-5  # zero potential at HCN minimum

    # call relativistic  correction

    rcor = _rel_corr(smallr, bigR, cosgamma)
    pot = pot + rcor

    # call DBOC correction

    DBOCcor = _DBOC_corr(smallr, bigR, cosgamma)
    pot = pot + DBOCcor

    return pot * 219474.624


#potv = jax.jit(jax.vmap(_potv, in_axes=0))
