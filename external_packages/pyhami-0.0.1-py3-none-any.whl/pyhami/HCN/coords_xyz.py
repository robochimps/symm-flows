# Jacobi coordinates for XYZ-molecule. XYZ: #e.g. HCN
# Masses are needed, thus the inclusion of self.
import jax
import numpy as np
from jax import numpy as jnp

from pyhami.keo import com

jax.config.update("jax_enable_x64", True)

m = np.array([1.007825031898, 12.0, 14.003074004251])  # H, C, N


@com
def internal_to_cartesian(internal_coords):
    smallr, bigr, angle = internal_coords
    r_com = m[1] * smallr / (m[2] + m[1])
    return jnp.array(
        [
            [bigr * jnp.sin(angle), 0.0, r_com + bigr * jnp.cos(angle)],  # H
            [0, 0.0, smallr],  # C
            [0.0, 0.0, 0.0],  # N
        ],
        dtype=jnp.float64,
    )


def cartesian_to_internal(self, xyz_coords):
    xA, xB, xC = xyz_coords  # H,C,N
    m = self.masses  # H,C,N
    r_CoM = (xC * m[2] + xB * m[1]) / (m[2] + m[1])
    v1 = xB - xC
    v2 = xA - r_CoM
    r1 = jnp.linalg.norm(v1)
    r2 = jnp.linalg.norm(v2)
    a = jnp.arccos(jnp.dot(v1, v2) / (r1 * r2))
    return jnp.array([r1, r2, a])