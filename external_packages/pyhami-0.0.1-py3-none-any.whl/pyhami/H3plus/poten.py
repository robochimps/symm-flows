import itertools
import os
from ctypes import CDLL, c_int

import jax
import jax.numpy as jnp
import numpy as np
from jax import config
from scipy import constants, optimize

# from py_np.potv import potv
from py_np.potv_jax import potv

config.update("jax_enable_x64", True)

AU_TO_INVCM = constants.value("hartree-inverse meter relationship") / 100

XMASS = np.array([0, 1.007537, 1.007537, 1.007537])
G1 = 0.5
G2 = 0.0

# potlib = CDLL("./potenlib.so")
potlib_path = os.path.dirname(__file__)
potlib = np.ctypeslib.load_library("potenlib", potlib_path)


@jax.custom_jvp
def poten_f(x):
    shape_dtype = jax.ShapeDtypeStruct((), x.dtype)
    return jax.pure_callback(_poten_f, shape_dtype, x, vmap_method="broadcast_all")


# def _poten_f(x):
#     """Fortran H3+ PES in Jacobi coordinates"""
#     potlib.potv_jacobi.argtypes = [
#         c_int,
#         np.ctypeslib.ndpointer(np.float64, ndim=1, flags="F_CONTIGUOUS"),
#         np.ctypeslib.ndpointer(np.float64, ndim=1, flags="F_CONTIGUOUS"),
#     ]
#     potlib.potv_jacobi.restype = None
#     npoints = len(x)
#     v = np.asfortranarray(np.zeros(npoints, dtype=np.float64))
#     points = np.array(x, dtype=np.float64).reshape(-1, order="F")
#     potlib.potv_jacobi(npoints, points, v)
#     return v


def _poten_f(x):
    """Fortran H3+ PES in R1,R2,R3 coordinates (excluding nonBO and relativistic corrections)"""
    potlib.newpot_dist.argtypes = [
        c_int,
        np.ctypeslib.ndpointer(np.float64, ndim=1, flags="F_CONTIGUOUS"),
        np.ctypeslib.ndpointer(np.float64, ndim=1, flags="F_CONTIGUOUS"),
    ]
    potlib.newpot_dist.restype = None
    npoints = len(x)
    v = np.asfortranarray(np.zeros(npoints, dtype=np.float64))
    points = np.array(x, dtype=np.float64).reshape(-1, order="F")
    potlib.newpot_dist(npoints, points, v)
    return v


# def _deriv_poten_f(x):
#     """Fortran H3+ PES derivative in Jacobi coordinates"""
#     potlib.deriv_potv_jacobi.argtypes = [
#         c_int,
#         np.ctypeslib.ndpointer(np.float64, ndim=1, flags="F_CONTIGUOUS"),
#         np.ctypeslib.ndpointer(np.float64, ndim=2, flags="F_CONTIGUOUS"),
#     ]
#     potlib.deriv_potv_jacobi.restype = None
#     npoints = len(x)
#     v = np.asfortranarray(np.zeros((npoints, 3), dtype=np.float64))
#     points = np.array(x, dtype=np.float64).reshape(-1, order="F")
#     potlib.deriv_potv_jacobi(npoints, points, v)
#     return v


def _deriv_poten_f(x):
    """Fortran H3+ PES derivative in R1,R2,R3 coordinates (excluding nonBO and relativistic corrections)"""
    potlib.deriv_newpot_dist.argtypes = [
        c_int,
        np.ctypeslib.ndpointer(np.float64, ndim=1, flags="F_CONTIGUOUS"),
        np.ctypeslib.ndpointer(np.float64, ndim=2, flags="F_CONTIGUOUS"),
    ]
    potlib.deriv_newpot_dist.restype = None
    npoints = len(x)
    v = np.asfortranarray(np.zeros((npoints, 3), dtype=np.float64))
    points = np.array(x, dtype=np.float64).reshape(-1, order="F")
    potlib.deriv_newpot_dist(npoints, points, v)
    return v


def _jvp_poten_f_deriv(x):
    shape_dtype = jax.ShapeDtypeStruct((3,), x.dtype)
    return jax.pure_callback(
        _deriv_poten_f, shape_dtype, x, vmap_method="broadcast_all"
    )


@poten_f.defjvp
def _poten_f_jvp(prim, tang):
    (x,) = prim
    (x_dot,) = tang
    prim_out = poten_f(x)
    tang_out = jnp.dot(_jvp_poten_f_deriv(x), x_dot)
    return prim_out, tang_out


def _test_callback():
    print("test callback of Fortran wrapper")
    r_small_list = np.linspace(0.6, 20.0, 10)
    r_big_list = np.linspace(0.3, 20.0, 10)
    theta_list = np.linspace(0.1, np.pi - 0.1, 10)
    x = np.array(
        [elem for elem in itertools.product(r_small_list, r_big_list, theta_list)]
    )
    v1 = _poten_f(x)
    dv1 = _deriv_poten_f(x)
    v2 = jax.jit(jax.vmap(poten_f, in_axes=0))(x)
    dv2 = jax.jit(jax.vmap(jax.jacrev(poten_f, argnums=0), in_axes=0))(x)
    print(np.max(np.abs(v1 - v2)))
    print(np.max(np.abs(dv1 - dv2)))


if __name__ == "__main__":

    _test_callback()

    print("find minimum of Fortran wrapper potential")
    vmin = optimize.minimize(lambda x: _poten_f(np.array([x])), [1.0, 1.0, np.pi / 2])
    r0 = vmin.x
    v0 = vmin.fun
    print("mininum of the potential:", r0, v0)
    # v0 = 0.0005127920387044907

    # print("find minimum of python potential")
    # vmin = optimize.minimize(
    #     lambda x: potv(x[0], x[1], np.cos(x[2]), G1, G2, XMASS), [1.0, 1.0, np.pi / 2]
    # )
    # r0_ = vmin.x
    # v0_ = vmin.fun
    # print("mininum of the potential:", r0_, v0_)

    print("test python vs Fortran wrapper on grid")
    r_small_list = np.linspace(0.6, 20.0, 10)
    r_big_list = np.linspace(0.3, 20.0, 10)
    theta_list = np.linspace(0.1, np.pi - 0.1, 10)
    x = np.array(
        [elem for elem in itertools.product(r_small_list, r_big_list, theta_list)]
    )

    v1 = jax.jit(jax.vmap(poten_f, in_axes=0))(x)
    v1 = (v1 - v0) * AU_TO_INVCM

    r1, r2, theta = x.T
    v2 = jax.jit(jax.vmap(potv, in_axes=(0, 0, 0, None, None, None)))(
        r1, r2, np.cos(theta), G1, G2, XMASS
    )
    v2 = (v2 - v0) * AU_TO_INVCM

    diff = np.abs(v1 - v2)

    ind = np.where((diff > 0.01) & (v1 < 40000.0))
    for d, v, x in zip(diff[ind], v1[ind], x[ind]):
        print(round(d, 6), round(v, 2), x.round(2))