import numpy as np
from polorder import npol, order
from switch import gam1, x0, r0, beta
from coef3 import coef3_x


def nparam(order):
    nparam = 0
    for l in range(0, order + 1):
        for i in range(0, l + 1):
            for j in range(0, (l - i) + 1, 2):
                k = l - i - j
                if k % 3 == 0:
                    nparam = nparam + 1
    return nparam


def singlet(r1, r2, r3, idimp):

    npar = np.zeros(5 + 1, dtype=int)
    npar[1] = nparam(order[1, 1]) + nparam(order[2, 1])
    npar[2] = nparam(order[1, 2])
    npar[3] = nparam(order[1, 3])
    npar[4] = nparam(order[1, 4])
    npar[5] = nparam(order[1, 5])

    tb = np.zeros(5 + 1, dtype=np.float64)

    if idimp == 0:
        inst = 1
        for nst in range(1, 5 + 1):
            tb[nst] = thrbody(coef3_x, r1, r2, r3, nst, inst)
            inst = inst + npar[nst]

    xdiag = tb[1]
    xodiag = tb[2]

    pot = dimpot(r1, r2, r3, xdiag, xodiag)

    pot[0] = pot[0] + tb[3]
    pot[1] = pot[1] + tb[4]
    pot[2] = pot[2] + tb[5]

    potdim = dimpot(r1, r2, r3, 0.0, 0.0)

    rm = np.array([0, r1, r2, r3])

    imin = -1
    rmin = rm[1]

    for i in range(1, 3 + 1):
        if rm[i] < rmin:
            rmin = rm[i]
            imin = i

    if imin > 1:
        rmin = rm[1]
        rm[1] = rm[imin]
        rm[imin] = rmin

    r = np.sqrt(np.abs(0.5 * rm[2] ** 2 + 0.5 * rm[3] ** 2 - 0.25 * rm[1] ** 2))

    r00 = 9
    br = 2
    delta = 0.1

    alphar = np.log(100 / delta - 1) / br

    fflowr = 1 / (1 + np.exp(-2 * alphar * (r - r00)))
    ffupr = 1 / (1 + np.exp(2 * alphar * (r - r00)))

    pot[0] = ffupr * pot[0] + fflowr * potdim[0]
    return pot


def thrbody(x, d1, d2, d3, nst, inst):

    r = np.zeros(3 + 1, dtype=np.float64)
    a = np.zeros((3 + 1, 3 + 1), dtype=np.float64)
    q = np.zeros(3 + 1, dtype=np.float64)

    r[1] = d1
    r[2] = d2
    r[3] = d3

    rho = np.sqrt((r[1] ** 2 + r[2] ** 2 + r[3] ** 2) / np.sqrt(3))
    a[1, 1] = np.sqrt(1 / 3)
    a[1, 2] = a[1, 1]
    a[1, 3] = a[1, 1]
    a[2, 1] = 0
    a[2, 2] = np.sqrt(1 / 2)
    a[2, 3] = -a[2, 2]
    a[3, 1] = np.sqrt(2 / 3)
    a[3, 2] = -np.sqrt(1 / 6)
    a[3, 3] = a[3, 2]

    num = inst - 1

    v = 0.0

    for nr in range(1, npol[nst] + 1):

        for i in range(1, 3 + 1):
            q[i] = 0
            for j in range(1, 3 + 1):
                q[i] = (
                    q[i]
                    + a[i, j]
                    * (1 - np.exp(-beta[nr, nst] * (r[j] / r0[nr, nst] - 1)))
                    / beta[nr, nst]
                )

        q1 = q[1]
        q2 = q[2] ** 2 + q[3] ** 2
        q3 = q[3] ** 3 - 3 * q[3] * q[2] ** 2
        
        for l in range(0, order[nr, nst] + 1):
            for i in range(0, l + 1):
                g1p = pow(q1, i)
                for j in range(0, (l - i) + 1, 2):
                    g2p = pow(q2, j / 2)
                    k = l - i - j
                    if np.mod(k, 3) == 0:
                        g3p = pow(q3, k / 3)
                        num = num + 1
                        v = v + x[num] * g1p * g2p * g3p * damp(
                            gam1[nr, nst], d1, x0[nr, nst]
                        ) * damp(gam1[nr, nst], d2, x0[nr, nst]) * damp(
                            gam1[nr, nst], d3, x0[nr, nst]
                        ) * damp(
                            gam1[nr, nst], q1, x0[nr, nst]
                        ) * damp(
                            gam1[nr, nst], q2, x0[nr, nst]
                        ) * damp(
                            gam1[nr, nst], q3, x0[nr, nst]
                        )
                        #               *damp(gam1[nr,nst],rho,x0[nr,nst])

    v = v * (1 - damp(10, d1, 0.8)) * (1 - damp(10, d2, 0.8)) * (1 - damp(10, d3, 0.8))

    return v


def damp(gam, q, qq):
    return 1 / (1 + np.exp(gam * (q - qq)))


def dimpot(r1, r2, r3, xdiag, xodiag):
    h = np.zeros((3, 3), dtype=np.float64)

    h[0, 0] = xh2pd(r2) + ah2pd(r2) + xh2pd(r3) + ah2pd(r3)
    h[0, 0] = 0.5 * h[0, 0] + pothhx(r1) + xdiag - 1.0

    h[1, 1] = xh2pd(r1) + ah2pd(r1) + xh2pd(r3) + ah2pd(r3)
    h[1, 1] = 0.5 * h[1, 1] + pothhx(r2) + xdiag - 1.0

    h[2, 2] = xh2pd(r1) + ah2pd(r1) + xh2pd(r2) + ah2pd(r2)
    h[2, 2] = 0.5 * h[2, 2] + pothhx(r3) + xdiag - 1.0

    h[0, 1] = 0.5 * (xh2pd(r3) - ah2pd(r3) - xodiag**2)
    h[1, 0] = h[0, 1]

    h[0, 2] = 0.5 * (xh2pd(r2) - ah2pd(r2) - xodiag**2)
    h[2, 0] = h[0, 2]

    h[1, 2] = 0.5 * (xh2pd(r1) - ah2pd(r1) - xodiag**2)
    h[2, 1] = h[1, 2]

    pot, _ = np.linalg.eigh(h)
    return pot


def xh2pd(r):
    d1 = np.zeros(20 + 1, dtype=np.float64)
    d2 = np.zeros(20 + 1, dtype=np.float64)
    c = np.zeros(20 + 1, dtype=np.float64)
    ai = np.zeros(11 + 1, dtype=np.float64)
    dd = np.zeros(20 + 1, dtype=np.float64)

    nlow = 4
    nupp = 11
    for ii in range(nlow, nupp + 1):
        d1[ii] = an(ii)
        d2[ii] = bn(ii)

    iexp = 1
    re = 2.0
    c[4] = 2.250
    c[5] = 0.0
    c[6] = 7.5000
    c[7] = 53.25
    c[8] = 65.625
    c[9] = 886.5
    c[10] = 1063.125
    c[11] = 21217.5
    gamma = 2.5
    agp = -0.180395506614312
    ai[1] = -0.897676265677028185
    ai[2] = -0.771599228853606545
    ai[3] = -0.245766669963638718
    ai[4] = -0.788889284685244524e-01
    ai[5] = -0.252032558464952844e-01
    ai[6] = 0.681894227468654839e-02
    ai[7] = 0.655940943163255976e-03
    ai[8] = -0.531288172311992135e-03
    ai[9] = 0.890418306898401330e-04
    ai[10] = -0.666314834544138477e-05
    ai[11] = 0.194182431833699709e-06
    g0 = 0.960151039243191562
    g1 = -0.353946173857859037
    g2 = -0.496213155382123572
    r0 = 3.4641
    rm = 0.11000000e02
    x = r - re

    pol1 = ai[11]

    for i in range(10, 0, -1):
        pol1 = pol1 * x + ai[i]

    pol1 = pol1 * x + 1.0

    gam = g0 * (1.0 + g1 * np.tanh(g2 * x))
    vhf = -agp / (r**iexp) * pol1 * np.exp(-gam * x)

    rhh = 0.5 * (rm + gamma * r0)
    x = r / rhh

    disp = 0.0
    for i in range(nlow, nupp + 1):
        dampi = (1.0 - np.exp(-d1[i] * x - d2[i] * x**2)) ** i
        dd[i] = dampi
        disp = disp - c[i] * dampi * r ** (-i)
    return vhf + disp


def ah2pd(r):
    coef = np.array(
        [
            1.11773285795729826,
            -1.27592697554394174,
            0.235612064424508216,
            -0.500203729467869895e-01,
            0.568627052480373801e-02,
            -0.382978465312642114e-03,
            0.149149267032670154e-04,
            -0.267518847221239873e-06,
        ]
    )

    v = coef[7]
    for i in range(6, -1, -1):
        v = v * r + coef[i]
    return np.exp(v) + xh2pd(r)


def pothhx(r):

    dd = np.zeros(20 + 1, dtype=np.float64)
    d1 = np.zeros(20 + 1, dtype=np.float64)
    d2 = np.zeros(20 + 1, dtype=np.float64)
    c = np.zeros(20 + 1, dtype=np.float64)
    ai = np.zeros(9 + 1, dtype=np.float64)
    atild = np.zeros(2 + 1, dtype=np.float64)

    nlow = 6
    nupp = 16
    for ii in range(nlow, nupp + 1):
        d1[ii] = an(ii)
        d2[ii] = bn(ii)
    catild = -0.8205
    atild[1] = 0.0
    atild[2] = 0.0
    alpht = 2.5
    gtild = 2.0
    iexp = 1
    re = 0.14010000e01
    c[6] = 0.64990000e01
    c[7] = 0.0
    c[8] = 0.12440000e03
    c[9] = 0.0
    c[10] = 0.32858000e04
    c[11] = -0.34750000e04
    c[12] = 0.12150000e06
    c[13] = -0.29140000e06
    c[14] = 0.60610000e07
    c[15] = -0.23050000e08
    c[16] = 0.39380000e09
    gamma = 2.5
    agp = 0.229794389784158
    ai[1] = 1.74651398886700093
    ai[2] = 0.631036031819560028
    ai[3] = 0.747363488024733624
    ai[4] = 0.956724297662875783e-01
    ai[5] = 0.131320504483065703
    ai[6] = -0.812200084994067194e-07
    ai[7] = 0.119803887928360935e-01
    ai[8] = -0.212584227748381302e-02
    ai[9] = 0.509125901134908042e-03
    g0 = 1.02072511539524680
    g1 = 1.82599688484061118
    g2 = 0.269916332495592104
    r0 = 0.69282032e01
    rm = 0.11000000e02
    x = r - re

    pol1 = ai[9]
    for i in range(8, 0, -1):
        pol1 = pol1 * x + ai[i]
    pol1 = pol1 * x + 1

    gam = g0 * (1 + g1 * np.tanh(g2 * x))
    vhf = -agp / (r**iexp) * pol1 * np.exp(-gam * x)

    asexc = 1
    for i in range(1, 2 + 1):
        asexc = asexc + atild[i] * r**i
    asexc = asexc * catild * r**alpht * np.exp(-gtild * r)

    rhh = 0.5 * (rm + gamma * r0)
    x = r / rhh
    dexc = (1 - np.exp(-d1[nlow] * x - d2[nlow] * x**2)) ** nlow

    asexc = asexc * dexc
    vhf = vhf + asexc

    disp = 0
    for i in range(nlow, nupp + 1):
        dampi = (1 - np.exp(-d1[i] * x - d2[i] * x**2)) ** i
        dd[i] = dampi
        disp = disp - c[i] * dampi * r ** (-i)
    return vhf + disp


def an(n):
    alph0 = 16.36606
    alph1 = 0.70172
    return alph0 / float(n) ** alph1


def bn(n):
    bet0 = 17.19338
    bet1 = 0.09574
    return bet0 * np.exp(-bet1 * n)