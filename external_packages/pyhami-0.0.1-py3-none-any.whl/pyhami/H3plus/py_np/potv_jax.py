import jax
import jax.numpy as jnp

jax.config.update("jax_enable_x64", True)

from .potvac_jax import potvac
from .potvrcb_jax import potvrcb
from .newpot_jax import newpot
from scipy.special import expit


def potv(r1, r2, xcos, g1, g2, xmass):
    toang = 0.5291772
    cmtoau = 219474.631
    a = 2.22600
    tiny = 9e-15

    def compute_values(g1, g2, r1, r2, xcos, tiny):
        def case_g1_zero(_):
            q1 = r1
            q2 = r2
            theta = jnp.arccos(xcos)
            cost = xcos
            return q1, q2, theta, cost

        def case_g2_zero(_):
            xx = r1 * g1
            yy = r1 * (1 - g1)
            q1 = jax.lax.select(
                (r2 == 0) | (xcos >= (1 - tiny)),
                jnp.abs(xx - r2),
                jax.lax.select(
                    xcos <= (tiny - 1),
                    xx + r2,
                    jnp.sqrt(xx**2 + r2**2 - 2 * xx * r2 * xcos),
                ),
            )
            q2 = jax.lax.select(
                (r2 == 0) | (xcos >= (1 - tiny)),
                yy + r2,
                jax.lax.select(
                    xcos <= (tiny - 1),
                    jnp.abs(yy + r2),
                    jnp.sqrt(yy**2 + r2**2 + 2 * yy * r2 * xcos),
                ),
            )
            cost = jax.lax.select(
                (r2 == 0) | (xcos >= (1 - tiny)),
                -1.0,
                jax.lax.select(
                    xcos <= (tiny - 1),
                    1.0,
                    (q1**2 + q2**2 - r1**2) / (2 * q1 * q2),
                ),
            )
            theta = jnp.arccos(cost)
            return q1, q2, theta, cost

        def case_else(_):
            f1 = 1 / (g1 + 1e-16)
            f2 = 1 / (g2 + 1e-16)
            f12 = 1 - f1 * f2
            p1 = r1 * (1 - f1) / (g2 * f12)
            p2 = r2 * (1 - f2) / (g1 * f12)
            s1 = r1 - p1
            s2 = r2 - p2
            q1 = jnp.sqrt(p1**2 + s2**2 + 2 * p1 * s2 * xcos) / (1 - g1)
            q2 = jnp.sqrt(p2**2 + s1**2 + 2 * p2 * s1 * xcos) / (1 - g2)
            q3 = jnp.sqrt(p1**2 + p2**2 - 2 * p1 * p2 * xcos)
            cost = (q1**2 + q2**2 - q3**2) / (2 * q1 * q2)
            theta = jnp.arccos(cost)
            return q1, q2, theta, cost

        q1, q2, theta, cost = jax.lax.cond(
            g1 == 0,
            case_g1_zero,
            lambda _: jax.lax.cond(g2 == 0, case_g2_zero, case_else, None),
            None,
        )
        return q1, q2, theta, cost

    q1, q2, theta, cost = compute_values(g1, g2, r1, r2, xcos, tiny)

    s1 = q1
    s2 = q2
    s3 = jnp.sqrt(s1 * s1 + s2 * s2 - 2 * s1 * s2 * cost)
    pot = newpot(s1, s2, s3)
    v = pot + 1.3438355735473

    ac = potvac(s1, s2, s3)

    rm = jnp.array([s1, s2, s3])
    rm = jnp.sort(rm)
    r0 = jnp.sqrt(jnp.abs(0.5 * rm[1] ** 2 + 0.5 * rm[2] ** 2 - 0.25 * rm[0] ** 2))

    ac0 = -114.5
    delta = 0.1
    r00 = 10
    ba = 1
    alphaa = jnp.log(100 / delta - 1) / ba

    ffupa = 1 / (1 + jnp.exp(2 * alphaa * (r0 - r00)))
    fflowa = 1 / (1 + jnp.exp(-2 * alphaa * (r0 - r00)))
    ac = ac * ffupa + ac0 * fflowa

    ac = jax.lax.cond(ac < -200.0, lambda _: -200.0, lambda _: ac, ac)

    ac = jax.lax.cond(ac > 0.0, lambda _: 0.0, lambda _: ac, ac)

    ac = (
        -ac
        * (1 / xmass[1] + 1 / xmass[2] + 1 / xmass[3])
        / 3
        / cmtoau
        * 1836.15
        / 1822.89
    )

    vr = potvrcb(s1, s2, s3)

    bu = 3
    vr0u = 6
    alphau = jnp.log(100 / delta - 1) / bu
    ffup = 1 / (1 + jnp.exp(2 * alphau * (jnp.abs(vr) - vr0u)))
    vr = vr * ffup

    vr = jax.lax.cond(jnp.abs(vr) > 10.0, lambda _: 0.0, lambda _: vr, vr)
    vr = vr / cmtoau
    return v + ac + vr