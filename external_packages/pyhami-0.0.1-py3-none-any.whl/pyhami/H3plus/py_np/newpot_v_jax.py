import jax
import jax.numpy as jnp

jax.config.update("jax_enable_x64", True)
from .dimh3p_jax import dimh3p
from scipy.special import expit


def newpot_v(r1, r2, r3):
    min_ = -1.3438355735473
    fac = 219474.631
    v = 0

    delta = 0.1
    bl = 80
    bu = 1400

    e0l = 40000
    e0u = 55000

    alphal = jnp.log(100 / delta - 1) / bl
    alphau = jnp.log(100 / delta - 1) / bu

    va = dimh3p(r1, r2, r3)
    vacm = (va[0] - min_) * fac

    fflow = 1 / (1 + jnp.exp(-2 * alphal * (vacm - e0l)))
    ffup = 1 / (1 + jnp.exp(2 * alphau * (vacm - e0u)))

    v = v_ai_diff_surf(r1, r2, r3)

    v = v * fflow * ffup
    vai = (va[0] - min_) * fac - v

    return vai / fac + min_


def v_ai_diff_surf(p1, p2, p3):
    re = 1.65000
    cv = jnp.array(
        [
            28.89617715,
            -10.58157805,
            2.87604608,
            2.08628333,
            -0.62636049,
            -0.51256565,
            -1.15962111,
            0.13476748,
            -0.08342574,
            0.29409500,
            0.10614684,
            -0.02831679,
            0.08313826,
            -0.01860622,
            -0.10208867,
            -0.03815698,
            0.00295364,
            -0.01213435,
            0.00056655,
            0.01681600,
            0.00053141,
            -0.00595500,
            -0.00116108,
            -0.00010578,
            0.00050616,
            -0.00000479,
            -0.00079326,
            0.00002889,
            0.00040228,
            0.00004892,
        ]
    )

    sq3 = jnp.sqrt(3.0)
    sq2 = jnp.sqrt(2.0)
    dr1 = p1 - re
    dr2 = p2 - re
    dr3 = p3 - re

    # Coordinate transformations
    y1 = dr1
    y2 = dr2
    y3 = dr3
    sa = (y1 + y2 + y3) / sq3
    sx1 = (dr2 + dr2 - dr1 - dr3) / (sq2 * sq3)
    sy1 = (dr1 - dr3) / sq2
    quad1 = sx1**2 + sy1**2
    se1 = jnp.sqrt(quad1)

    # this returns right function but Nan on gradient
    # phi = jnp.where(jnp.abs(se1) < 1.0e-10, jnp.arccos(0.0), jnp.arccos(sx1 / se1))
    #
    # .. to fix this, implement double 'where'
    se1_ = jnp.where(jnp.abs(se1) < 1e-10, 1.0, se1)
    phi = jnp.where(jnp.abs(se1) < 1e-10, 0.5 * jnp.pi, jnp.arccos(sx1 / se1_))

    indices = jnp.array(
        [
            [1, 0, 0],
            [2, 0, 0],
            [0, 0, 2],
            [3, 0, 0],
            [1, 0, 2],
            [0, 3, 0],
            [4, 0, 0],
            [2, 0, 2],
            [1, 3, 0],
            [0, 0, 4],
            [5, 0, 0],
            [3, 0, 2],
            [2, 3, 0],
            [1, 0, 4],
            [0, 3, 2],
            [6, 0, 0],
            [4, 0, 2],
            [3, 3, 0],
            [2, 0, 4],
            [1, 3, 2],
            [0, 0, 6],
            [0, 6, 0],
            [7, 0, 0],
            [5, 0, 2],
            [4, 3, 0],
            [3, 0, 4],
            [2, 3, 2],
            [1, 0, 6],
            [1, 6, 0],
            [0, 3, 4],
        ]
    )

    ind = jnp.array(
        [
            [1, 0, 0, 1],
            [2, 0, 0, 2],
            [0, 2, 0, 3],
            [3, 0, 0, 4],
            [1, 2, 0, 5],
            [0, 0, 3, 6],
            [4, 0, 0, 7],
            [2, 2, 0, 8],
            [1, 0, 3, 9],
            [0, 4, 0, 10],
            [5, 0, 0, 11],
            [3, 2, 0, 12],
            [2, 0, 3, 13],
            [1, 4, 0, 14],
            [0, 2, 3, 15],
            [6, 0, 0, 16],
            [4, 2, 0, 17],
            [3, 0, 3, 18],
            [2, 4, 0, 19],
            [1, 2, 3, 20],
            [0, 6, 0, 21],
            [0, 0, 6, 22],
            [7, 0, 0, 23],
            [5, 2, 0, 24],
            [4, 0, 3, 25],
            [3, 4, 0, 26],
            [2, 2, 3, 27],
            [1, 6, 0, 28],
            [1, 0, 6, 29],
        ]
    )

    # powers_sa = sa ** indices[:, 0]
    # powers_se1_phi = se1 ** (indices[:, 2] + indices[:, 1]) * jnp.cos(
    #     indices[:, 1] * phi
    # )
    # ft = jnp.concatenate([jnp.array([1.0]), powers_sa * powers_se1_phi])
    # return jnp.dot(cv, ft[:-1])

    n, m, k, c = ind.T
    powers = jnp.pow(sa, n) * jnp.pow(se1, (m + k)) * jnp.cos(k * phi)
    ft = jnp.concatenate([jnp.array([1.0]), powers])
    return jnp.sum(cv * ft)