import jax
import jax.numpy as jnp
jax.config.update("jax_enable_x64", True)

# Initialize the arrays
npol = jnp.zeros(6, dtype=jnp.int64)  # Shape (5+1)
order = jnp.zeros((6, 6), dtype=jnp.int64)  # Shape (5+1, 5+1)

# Update the arrays using `at` to maintain immutability
npol = npol.at[1].set(2).at[2].set(1).at[3].set(1).at[4].set(1).at[5].set(1)
order = order.at[1, 1].set(-1).at[2, 1].set(15).at[1, 2].set(13).at[1, 3].set(-1).at[1, 4].set(-1).at[1, 5].set(-1)