import numpy as np

gam1 = np.zeros((5 + 1, 5 + 1), dtype=np.float64)
x0 = np.zeros((5 + 1, 5 + 1), dtype=np.float64)
r0 = np.zeros((5 + 1, 5 + 1), dtype=np.float64)
beta = np.zeros((5 + 1, 5 + 1), dtype=np.float64)

gam1[1, 1] = 0.3
r0[1, 1] = 1.65
beta[1, 1] = 1.3
x0[1, 1] = 12.0

gam1[2, 1] = 0.3
r0[2, 1] = 2.5
beta[2, 1] = 1.0
x0[2, 1] = 14.0

gam1[1, 2] = 0.3
r0[1, 2] = 2.5
beta[1, 2] = 1.0
x0[1, 2] = 14.0

gam1[1, 3] = 0.3
r0[1, 3] = 2.5
beta[1, 3] = 1.0
x0[1, 3] = 10.0

gam1[1, 4] = 0.3
r0[1, 4] = 2.5
beta[1, 4] = 1.0
x0[1, 4] = 12.0

gam1[1, 5] = 0.3
r0[1, 5] = 2.5
beta[1, 5] = 1.0
x0[1, 5] = 12.0