import numpy as np


def dim_ai_diff_surf(p1, p2, p3):
    re = 1.65000
    nfmax = 7
    cv = np.array(
        [
            -0.75143071,
            -1.76440106,
            -0.09859390,
            -0.99200748,
            1.48567895,
            -4.46772673,
            -3.90622308,
            -0.37926323,
            1.53719611,
            2.48855132,
            1.37657184,
            -0.01544350,
            0.07169542,
            -0.37054284,
            -0.68993265,
            -0.20471568,
            0.00037056,
            0.00167004,
            0.00764265,
            -0.00024218,
            0.02173168,
            0.04686634,
            -0.00943583,
            0.00077371,
            -0.00681003,
            -0.00285356,
            0.01863322,
            0.01297023,
            -0.01472313,
            0.00114263,
            -0.01094351,
        ],
        dtype=np.float64,
    )
    ft = np.zeros(len(cv), dtype=np.float64)

    sq3 = np.sqrt(3)
    sq2 = np.sqrt(2)
    dr1 = p1 - re
    dr2 = p2 - re
    dr3 = p3 - re

    y1 = dr1
    y2 = dr2
    y3 = dr3
    sa = (y1 + y2 + y3) / sq3
    sx1 = (dr2 + dr2 - dr1 - dr3) / (sq2 * sq3)
    sy1 = (dr1 - dr3) / sq2
    quad1 = sx1**2 + sy1**2
    se1 = np.sqrt(quad1)
    if abs(se1) < 1.0e-10:
        phi = np.arccos(0)
    else:
        phi = np.arccos(sx1 / se1)

    npot = 0
    ft[0] = 1
    for norder in range(1, nfmax + 1):
        for n in range(norder, -1, -1):
            for k in range(0, norder - n + 1, 3):
                if k % 3 != 0:
                    continue
                m = norder - k - n
                if m % 2 != 0:
                    continue
                npot = npot + 1
                if npot > len(cv) - 1:
                    break
                ft[npot] = sa**n * se1 ** (m + k) * np.cos(k * phi)

    return np.dot(cv, ft)