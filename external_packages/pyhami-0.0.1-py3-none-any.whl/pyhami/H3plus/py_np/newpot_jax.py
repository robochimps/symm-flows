import jax
import jax.numpy as jnp
jax.config.update("jax_enable_x64", True)

from .singlet_jax import singlet
from .dimh3p_jax import dimh3p
from .newpot_v_jax import newpot_v
from .dim_ai_diff_surf_jax import dim_ai_diff_surf
from scipy.special import expit

def newpot(r1, r2, r3, coef3_x):
    min_ = -1.3438355735473
    fac = 219474.631
    v = 0

    delta = 0.1
    bl = 100
    bu = 300

    e0l = 37000
    e0u = 48000

    alphal = jnp.log(100 / delta - 1) / bl
    alphau = jnp.log(100 / delta - 1) / bu

    v3bt = singlet(r1, r2, r3, 0, coef3_x)

    vaug = dimh3p(r1, r2, r3)

    vaf = newpot_v(r1, r2, r3)

    vaugcm = (vaug[0] - min_) * fac
    vafcm = (vaf - min_) * fac

    fflow = 1 / (1 + jnp.exp(-2 * alphal * (vaugcm - e0l)))
    ffup = 1 / (1 + jnp.exp(2 * alphau * (vaugcm - e0u)))

    v = dim_ai_diff_surf(r1, r2, r3)
    v = v * fflow * ffup

    vlow = (v3bt[0] - min_) * fac - v

    e02 = 42000
    de2 = vafcm - e02

    ga02 = 1.71 / fac / fac / 100
    ga12 = 2000 / fac / fac / 100
    ga2 = ga02 + ga12 * (de2**2)

    ffup2 = 0.5 * (1 + jnp.tanh(ga2 * de2))
    fflow2 = 0.5 * (1 + jnp.tanh(-ga2 * de2))

    vaie = fflow2 * vlow + ffup2 * vafcm

    rm = jnp.array([r1, r2, r3])
    rm = jnp.sort(rm)

    r = jnp.sqrt(jnp.abs(0.5 * rm[1] ** 2 + 0.5 * rm[2] ** 2 - 0.25 * rm[0] ** 2))

    r0 = 18
    br = 1

    alphar = jnp.log(100 / delta - 1) / br

    fflowr = 1 / (1 + jnp.exp(-2 * alphar * (r - r0)))
    ffupr = 1 / (1 + jnp.exp(2 * alphar * (r - r0)))

    vair = ffupr * vaie + fflowr * vaugcm
    return vair / fac + min_