import jax
import jax.numpy as jnp

jax.config.update("jax_enable_x64", True)


def dim_ai_diff_surf(p1, p2, p3):
    re = 1.65000
    nfmax = 7
    cv = jnp.array(
        [
            -0.75143071,
            -1.76440106,
            -0.09859390,
            -0.99200748,
            1.48567895,
            -4.46772673,
            -3.90622308,
            -0.37926323,
            1.53719611,
            2.48855132,
            1.37657184,
            -0.01544350,
            0.07169542,
            -0.37054284,
            -0.68993265,
            -0.20471568,
            0.00037056,
            0.00167004,
            0.00764265,
            -0.00024218,
            0.02173168,
            0.04686634,
            -0.00943583,
            0.00077371,
            -0.00681003,
            -0.00285356,
            0.01863322,
            0.01297023,
            -0.01472313,
            0.00114263,
            -0.01094351,
        ]
    )

    sq3 = jnp.sqrt(3)
    sq2 = jnp.sqrt(2)
    dr1 = p1 - re
    dr2 = p2 - re
    dr3 = p3 - re

    y1 = dr1
    y2 = dr2
    y3 = dr3
    sa = (y1 + y2 + y3) / sq3
    sx1 = (dr2 + dr2 - dr1 - dr3) / (sq2 * sq3)
    sy1 = (dr1 - dr3) / sq2
    quad1 = sx1**2 + sy1**2
    se1 = jnp.sqrt(quad1)

    # this returns right function but Nan on gradient
    # phi = jnp.where(jnp.abs(se1) < 1.0e-10, jnp.arccos(0), jnp.arccos(sx1 / se1))
    #
    # .. to fix this, implement double 'where'
    se1_ = jnp.where(jnp.abs(se1) < 1e-10, 1.0, se1)
    phi = jnp.where(jnp.abs(se1) < 1e-10, 0.5 * jnp.pi, jnp.arccos(sx1 / se1_))

    indices = jnp.array(
        [
            [1, 0, 0],
            [2, 0, 0],
            [0, 2, 0],
            [3, 0, 0],
            [1, 2, 0],
            [0, 0, 3],
            [4, 0, 0],
            [2, 2, 0],
            [1, 0, 3],
            [0, 4, 0],
            [5, 0, 0],
            [3, 2, 0],
            [2, 0, 3],
            [1, 4, 0],
            [0, 2, 3],
            [6, 0, 0],
            [4, 2, 0],
            [3, 0, 3],
            [2, 4, 0],
            [1, 2, 3],
            [0, 6, 0],
            [0, 0, 6],
            [7, 0, 0],
            [5, 2, 0],
            [4, 0, 3],
            [3, 4, 0],
            [2, 2, 3],
            [1, 6, 0],
            [1, 0, 6],
            [0, 4, 3],
        ],
        dtype=int,
    )

    sa_powers = sa ** indices[:, 0]
    se1_phi_powers = se1 ** (indices[:, 1] + indices[:, 2]) * jnp.cos(
        indices[:, 2] * phi
    )
    ft_values = sa_powers * se1_phi_powers

    ft = jnp.concatenate([jnp.array([1.0]), ft_values[: len(cv) - 1]])
    return jnp.dot(cv, ft)