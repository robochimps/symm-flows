import numpy as np
from .singlet import singlet
from .dimh3p import dimh3p
from .newpot_v import newpot_v
from .dim_ai_diff_surf import dim_ai_diff_surf
from scipy.special import expit

def newpot(r1, r2, r3):

    min = -1.3438355735473
    fac = 219474.631
    v = 0

    delta = 0.1
    bl = 100
    bu = 300

    e0l = 37000
    e0u = 48000

    alphal = np.log(100 / delta - 1) / bl
    alphau = np.log(100 / delta - 1) / bu

    v3bt = singlet(r1, r2, r3, 0)

    vaug = dimh3p(r1, r2, r3)

    vaf = newpot_v(r1, r2, r3)

    vaugcm = (vaug[0] - min) * fac
    vafcm = (vaf - min) * fac

    fflow = 1 / (1 + np.exp(-2 * alphal * (vaugcm - e0l)))
    ffup = 1 / (1 + np.exp(2 * alphau * (vaugcm - e0u)))
    # fflow = expit(-2 * alphal * (vaugcm - e0l))
    # ffup = expit(2 * alphau * (vaugcm - e0u))

    v = dim_ai_diff_surf(r1, r2, r3)

    v = v * fflow * ffup

    vlow = (v3bt[0] - min) * fac - v

    e02 = 42000
    de2 = vafcm - e02

    ga02 = 1.71 / fac / fac / 100
    ga12 = 2000 / fac / fac / 100
    ga2 = ga02 + ga12 * (de2**2)

    ffup2 = 0.5 * (1 + np.tanh(ga2 * de2))
    fflow2 = 0.5 * (1 + np.tanh(-ga2 * de2))

    vaie = fflow2 * vlow + ffup2 * vafcm

    rm = np.array([0, r1, r2, r3])
    imin = -1
    rmin = rm[1]

    for i in range(1, 3 + 1):
        if rm[i] < rmin:
            rmin = rm[i]
            imin = i

    if imin > 1:
        rmin = rm[1]
        rm[1] = rm[imin]
        rm[imin] = rmin

    r = np.sqrt(np.abs(0.5 * rm[2] ** 2 + 0.5 * rm[3] ** 2 - 0.25 * rm[1] ** 2))

    r0 = 18
    br = 1

    alphar = np.log(100 / delta - 1) / br

    fflowr = 1 / (1 + np.exp(-2 * alphar * (r - r0)))
    ffupr = 1 / (1 + np.exp(2 * alphar * (r - r0)))

    vair = ffupr * vaie + fflowr * vaugcm
    return vair / fac + min