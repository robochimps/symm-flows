import numpy as np

npol = np.zeros((5 + 1), dtype=int)
order = np.zeros((5 + 1, 5 + 1), dtype=int)

npol[1] = 2
npol[2] = 1
npol[3] = 1
npol[4] = 1
npol[5] = 1
order[1, 1] = -1
order[2, 1] = 15
order[1, 2] = 13
order[1, 3] = -1
order[1, 4] = -1
order[1, 5] = -1