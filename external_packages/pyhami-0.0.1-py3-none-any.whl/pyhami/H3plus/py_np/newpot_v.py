import numpy as np
from .dimh3p import dimh3p
from scipy.special import expit


def newpot_v(r1, r2, r3):
    min = -1.3438355735473
    fac = 219474.631
    v = 0

    delta = 0.1
    bl = 80
    bu = 1400

    e0l = 40000
    e0u = 55000

    alphal = np.log(100 / delta - 1) / bl
    alphau = np.log(100 / delta - 1) / bu

    va = dimh3p(r1, r2, r3)
    vacm = (va[0] - min) * fac

    fflow = 1 / (1 + np.exp(-2 * alphal * (vacm - e0l)))
    ffup = 1 / (1 + np.exp(2 * alphau * (vacm - e0u)))
    # fflow = expit(-2 * alphal * (vacm - e0l))
    # ffup = expit(2 * alphau * (vacm - e0u))

    v = v_ai_diff_surf(r1, r2, r3)

    v = v * fflow * ffup
    vai = (va[0] - min) * fac - v

    return vai / fac + min


def v_ai_diff_surf(p1, p2, p3):

    nfmax = 7
    re = 1.65000
    cv = np.array(
        [
            28.89617715,
            -10.58157805,
            2.87604608,
            2.08628333,
            -0.62636049,
            -0.51256565,
            -1.15962111,
            0.13476748,
            -0.08342574,
            0.29409500,
            0.10614684,
            -0.02831679,
            0.08313826,
            -0.01860622,
            -0.10208867,
            -0.03815698,
            0.00295364,
            -0.01213435,
            0.00056655,
            0.01681600,
            0.00053141,
            -0.00595500,
            -0.00116108,
            -0.00010578,
            0.00050616,
            -0.00000479,
            -0.00079326,
            0.00002889,
            0.00040228,
            0.00004892,
        ]
    )
    ft = np.zeros(len(cv), dtype=np.float64)

    sq3 = np.sqrt(3)
    sq2 = np.sqrt(2)
    dr1 = p1 - re
    dr2 = p2 - re
    dr3 = p3 - re

    y1 = dr1
    y2 = dr2
    y3 = dr3
    sa = (y1 + y2 + y3) / sq3
    sx1 = (dr2 + dr2 - dr1 - dr3) / (sq2 * sq3)
    sy1 = (dr1 - dr3) / sq2
    quad1 = sx1**2 + sy1**2
    se1 = np.sqrt(quad1)
    if np.abs(se1) < 1.0e-10:
        phi = np.arccos(0)
    else:
        phi = np.arccos(sx1 / se1)

    npot = 0
    ft[0] = 1
    for norder in range(1, nfmax + 1):
        for n in range(norder, -1, -1):
            for k in range(0, norder - n + 1, 3):
                if k % 3 != 0:
                    continue
                m = norder - k - n
                if m % 2 != 0:
                    continue
                npot = npot + 1
                if npot > len(cv) - 1:
                    break
                ft[npot] = sa**n * se1 ** (m + k) * np.cos(float(k) * phi)

    return np.dot(cv, ft)