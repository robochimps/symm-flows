import jax
import jax.numpy as jnp
jax.config.update("jax_enable_x64", True)

import numpy as np
# from .coef3_jax import coef3_x
from .valid_lij import valid_13, valid_15


def singlet(r1, r2, r3, idimp, coef3_x):
    tb0, tb1 = jax.lax.cond(
        idimp == 0,  
        lambda _: (thrbody_new(coef3_x[:175], r1, r2, r3, 1, 2, 2, 1, valid_15),
                   thrbody_new(coef3_x[175:], r1, r2, r3, 2, 1, 1, 175, valid_13)),
        lambda _: (0.0, 1.0),
        idimp
    )

    pot = dimpot(r1, r2, r3, tb0, tb1)
    potdim = dimpot(r1, r2, r3, 0.0, 0.0)
    rm = jnp.array([r1, r2, r3])

    imin = jnp.argmin(rm)  # 1-based indexing
    rmin = rm[imin]

    rm = jax.lax.cond(
        imin > 0,
        lambda rm: rm.at[0].set(rmin).at[imin].set(rm[0]),
        lambda rm: rm,
        rm
    )
    
    r = jnp.sqrt(jnp.abs(0.5 * rm[1] ** 2 + 0.5 * rm[2] ** 2 - 0.25 * rm[0] ** 2))
    r00,br,delta = 9,2,0.1

    alphar = jnp.log(100 / delta - 1) / br

    fflowr = 1 / (1 + jnp.exp(-2 * alphar * (r - r00)))
    ffupr = 1 / (1 + jnp.exp(2 * alphar * (r - r00)))

    pot = pot.at[0].set(ffupr * pot[0] + fflowr * potdim[0])
    return pot


def thrbody_new(x, d1, d2, d3, nst, npol, nr, inst, valid):
    r = jnp.array([d1, d2, d3], dtype=jnp.float64)  # r[0] as d1, r[1] as d2, r[2] as d3
    a = jnp.array([[jnp.sqrt(1 / 3), jnp.sqrt(1 / 3), jnp.sqrt(1 / 3)],
                  [0.0, jnp.sqrt(1 / 2), -jnp.sqrt(1 / 2)],
                  [jnp.sqrt(2 / 3), -jnp.sqrt(1 / 6), -jnp.sqrt(1 / 6)]], dtype=jnp.float64)

    rho = jnp.sqrt((r[0] ** 2 + r[1] ** 2 + r[2] ** 2) / jnp.sqrt(3))

    num = inst - 1

    gam1, beta, x0, r0 = 0.3, 1.0, 14.0, 2.5 #Many redundant indexes in original code!
    q = jnp.einsum('ij,j->i', a, (1 - jnp.exp(-beta * (r / r0 - 1)))/beta)
    q1 = q[0]
    q2 = q[1] ** 2 + q[2] ** 2
    q3 = q[2] ** 3 - 3 * q[2] * q[1] ** 2

    def check_valid(lij):
        return 0.5 * (1 - jnp.sign(-jnp.prod(lij,axis=1)-0.1)) #-0.1 because zero returns 0
    valid_sum = check_valid(valid)
    v = damp(gam1, d1, x0) * damp(gam1, d2, x0) * damp(gam1, d3, x0) * damp(gam1, q1, x0) \
        * damp(gam1, q2, x0) * damp(gam1, q3, x0)
    v = v * jnp.sum(valid_sum * x * q1**valid[:,1] * q2**(valid[:,2]/2) * q3**((valid[:,0]-valid[:,1]-valid[:,2])/3))
    v = v * (1 - damp(10, d1, 0.8)) * (1 - damp(10, d2, 0.8)) * (1 - damp(10, d3, 0.8))
    return v

def damp(gam, q, qq):
    return 1 / (1 + jnp.exp(gam * (q - qq)))


def dimpot(r1, r2, r3, xdiag, xodiag):
    a = 0.5 * (xh2pd(r2) + ah2pd(r2) + xh2pd(r3) + ah2pd(r3)) + pothhx(r1) + xdiag - 1.0
    d = 0.5 * (xh2pd(r3) - ah2pd(r3) - xodiag**2)
    f = 0.5 * (xh2pd(r2) - ah2pd(r2) - xodiag**2)
    b = 0.5 * (xh2pd(r1) + ah2pd(r1) + xh2pd(r3) + ah2pd(r3)) + pothhx(r2) + xdiag - 1.0
    e = 0.5 * (xh2pd(r1) - ah2pd(r1) - xodiag**2)
    c = 0.5 * (xh2pd(r1) + ah2pd(r1) + xh2pd(r2) + ah2pd(r2)) + pothhx(r3) + xdiag - 1.0
    #h = jnp.array([[a,d,f],[d,b,e],[f,e,c]])
    #pot, _ = jnp.linalg.eigh(h)

    #analytical eigenvalues of 3x3 Hermitian matrix
    x1 = a**2 + b**2 + c**2 - a*b - a*c - b*c + 3 * (d**2 + f**2 + e**2) 
    x2 = -(2*a-b-c)*(2*b-a-c)*(2*c-a-b) + 9*((2*c-a-b)*d**2 + (2*b-a-c)*f**2+(2*a-b-c)*e**2) - 54 * d * e * f
    
    phi = jax.lax.cond(
        x2 == 0,
        lambda _: jnp.pi / 2,  # Case where x2 == 0
        lambda _: jax.lax.cond(
            x2 > 0,
            lambda _: jnp.arctan(jnp.sqrt(jnp.abs(4 * x1**3 - x2**2)) / x2), 
            lambda _: jnp.arctan(jnp.sqrt(jnp.abs(4 * x1**3 - x2**2)) / x2) + jnp.pi,  
            operand=None  
        ),
        operand=None)
        
    pot = (a + b + c - 2*jnp.sqrt(x1) * jnp.cos(phi/3)) / 3
    return jnp.array([pot,0,0])


def xh2pd(r):
    j_list = jnp.arange(8)+4
    d1 = an(j_list)
    d2 = bn(j_list)
    c = jnp.array([2.250, 0.0, 7.5000, 53.25, 65.625, 886.5, 1063.125, 21217.5], dtype=jnp.float64)
    ai = jnp.array([0.194182431833699709e-06, -0.666314834544138477e-05, 
        0.890418306898401330e-04, -0.531288172311992135e-03, 
        0.655940943163255976e-03, 0.681894227468654839e-02, 
        -0.252032558464952844e-01, -0.788889284685244524e-01, 
        -0.245766669963638718, -0.771599228853606545, 
        -0.897676265677028185, 1.0], dtype=jnp.float64) #1.0 appended for scan and reversed order

    gamma, agp,g0,g1,g2,r0,rm,re,iexp  = 2.5,-0.180395506614312,0.960151039243191562,-0.353946173857859037,-0.496213155382123572,3.4641,11.0,2.0,1

    def compute_polynomial(r, re, ai, x):
        def body_fn(carry, coeff):
            carry = carry * x + coeff
            return carry, None
        pol1, _ = jax.lax.scan(body_fn, ai[0], ai[1:])
        return pol1
        
    x = r - re
    pol1 = compute_polynomial(r, re, ai, x)
    gam = g0 * (1.0 + g1 * jnp.tanh(g2 * x))
    vhf = -agp / (r**iexp) * pol1 * jnp.exp(-gam * x)
    rhh = 0.5 * (rm + gamma * r0)
    x = r / rhh
    i_list = jnp.arange(4, 12)
    disp = -jnp.einsum('i, i, i ->', c, (1.0 - jnp.exp(-d1 * x - d2 * x**2))**i_list, r**(-i_list))
    return vhf + disp

def ah2pd(r):
    coef = jnp.array([-0.267518847221239873e-06,0.149149267032670154e-04,-0.382978465312642114e-03,0.568627052480373801e-02,
        -0.500203729467869895e-01,0.235612064424508216,-1.27592697554394174,1.11773285795729826], dtype=jnp.float64)

    def body_fn(carry, coeff):
        carry = carry * r + coeff
        return carry, None
    
    v, _ = jax.lax.scan(body_fn, coef[0], coef[1:])
    
    return jnp.exp(v) + xh2pd(r)


def pothhx(r):
    c = jnp.array([0.64990000e01, 0.0, 0.12440000e03, 0.0, 0.32858000e04, -0.34750000e04,
                   0.12150000e06, -0.29140000e06, 0.60610000e07, -0.23050000e08, 0.39380000e09], dtype=jnp.float64)
    
    ai = jnp.array([ 0.509125901134908042e-03,-0.212584227748381302e-02,0.119803887928360935e-01,-0.812200084994067194e-07,
        0.131320504483065703,0.956724297662875783e-01,0.747363488024733624,0.631036031819560028,1.74651398886700093,1.0], dtype=jnp.float64) #1.0 appended for scan and reversed order

    nlow,nupp = 6,16

    i_list = jnp.arange(nupp - nlow + 1) + nlow
    d1 = an(i_list)
    d2 = bn(i_list)
    
    catild,alpht,gtild,iexp,re,gamma,agp = -0.8205,2.5,2.0,1,0.14010000e01,2.5,0.229794389784158
    g0,g1,g2,r0,rm = 1.02072511539524680,1.82599688484061118,0.269916332495592104,0.69282032e01,0.11000000e02
    x = r - re

    def compute_polynomial(r, re, ai, x):
        def body_fn(carry, coeff):
            carry = carry * x + coeff
            return carry, None
        pol1, _ = jax.lax.scan(body_fn, ai[0], ai[1:])
        return pol1
        
    pol1 = compute_polynomial(r, re, ai, x)

    gam = g0 * (1 + g1 * jnp.tanh(g2 * x))
    vhf = -agp / (r**iexp) * pol1 * jnp.exp(-gam * x)

    asexc = catild * r**alpht * jnp.exp(-gtild * r)
    rhh = 0.5 * (rm + gamma * r0)
    x = r / rhh
    dexc = (1 - jnp.exp(-d1[0] * x - d2[0] * x**2)) ** nlow
    asexc = asexc * dexc
    vhf = vhf + asexc
    def body_fn(carry, i):
        dampi = (1 - jnp.exp(-d1[i] * x - d2[i] * x**2)) ** (i + nlow)
        carry = carry - c[i] * dampi * r ** (-(i+nlow))  
        return carry, None

    disp, _ = jax.lax.scan(body_fn, 0.0, jnp.arange(0, nupp - nlow + 1))
    return vhf + disp

def an(n):
    alph0 = 16.36606
    alph1 = 0.70172
    return alph0 / n ** alph1


def bn(n):
    bet0 = 17.19338
    bet1 = 0.09574
    return bet0 * jnp.exp(-bet1 * n)