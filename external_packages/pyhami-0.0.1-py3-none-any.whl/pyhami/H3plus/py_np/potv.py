import numpy as np
from .potvac import potvac
from .potvrcb import potvrcb
from .newpot import newpot
from scipy.special import expit


def potv(r1, r2, xcos, g1, g2, xmass):

    toang = 0.5291772
    cmtoau = 219474.631
    a = 2.22600
    tiny = 9e-15

    if g1 == 0:
        q1 = r1
        q2 = r2
        theta = np.arccos(xcos)
        cost = xcos
    elif g2 == 0:
        xx = r1 * g1
        yy = r1 * (1 - g1)
        if r2 == 0 or xcos >= (1 - tiny):
            q1 = np.abs(xx - r2)
            q2 = yy + r2
            cost = -1
        elif xcos <= (tiny - 1):
            q1 = xx + r2
            q2 = np.abs(yy + r2)
            cost = 1
        else:
            q1 = np.sqrt(xx * xx + r2 * r2 - 2 * xx * r2 * xcos)
            q2 = np.sqrt(yy * yy + r2 * r2 + 2 * yy * r2 * xcos)
            cost = (q1**2 + q2**2 - r1**2) / (2 * q1 * q2)
        theta = np.arccos(cost)
    else:
        f1 = 1 / g1
        f2 = 1 / g2
        f12 = 1 - f1 * f2
        p1 = r1 * (1 - f1) / (g2 * f12)
        p2 = r2 * (1 - f2) / (g1 * f12)
        s1 = r1 - p1
        s2 = r2 - p2
        q1 = np.sqrt(p1 * p1 + s2 * s2 + 2 * p1 * s2 * xcos) / (1 - g1)
        q2 = np.sqrt(p2 * p2 + s1 * s1 + 2 * p2 * s1 * xcos) / (1 - g2)
        q3 = np.sqrt(p1 * p1 + p2 * p2 - 2 * p1 * p2 * xcos)
        cost = (q1 * q1 + q2 * q2 - q3 * q3) / (2 * q1 * q2)
        theta = np.arccos(cost)

    s1 = q1
    s2 = q2
    s3 = np.sqrt(s1 * s1 + s2 * s2 - 2 * s1 * s2 * cost)
    pot = newpot(s1, s2, s3)
    v = pot + 1.3438355735473

    ac = potvac(s1, s2, s3)

    rm = np.array([0, s1, s2, s3])

    jmin = -1
    rmin = rm[1]

    for j in range(1, 3 + 1):
        if rm[j] < rmin:
            rmin = rm[j]
            jmin = j

    if jmin > 1:
        rmin = rm[1]
        rm[1] = rm[jmin]
        rm[jmin] = rmin

    r0 = np.sqrt(np.abs(0.5 * rm[2] ** 2 + 0.5 * rm[3] ** 2 - 0.25 * rm[1] ** 2))

    ac0 = -114.5
    delta = 0.1
    r00 = 10
    ba = 1
    alphaa = np.log(100 / delta - 1) / ba

    ffupa = 1 / (1 + np.exp(2 * alphaa * (r0 - r00)))
    fflowa = 1 / (1 + np.exp(-2 * alphaa * (r0 - r00)))
    ac = ac * ffupa + ac0 * fflowa

    if ac < -200:
        ac = -200
    if ac > 0:
        ac = 0
    ac = (
        -ac
        * (1 / xmass[1] + 1 / xmass[2] + 1 / xmass[3])
        / 3
        / cmtoau
        * 1836.15
        / 1822.89
    )

    vr = potvrcb(s1, s2, s3)
    bu = 3
    vr0u = 6
    alphau = np.log(100 / delta - 1) / bu
    ffup = 1 / (1 + np.exp(2 * alphau * (np.abs(vr) - vr0u)))
    vr = vr * ffup
    
    if np.abs(vr) > 10:
        vr = 0
    vr = vr / cmtoau
    return v + ac + vr
