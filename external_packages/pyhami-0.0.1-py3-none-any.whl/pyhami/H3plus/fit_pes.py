import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax import linen as nn
from flax import serialization
from jax import config
from poten import _poten_f, poten_f
from py_np.coef3_jax import coef3_x
from py_np.newpot import newpot as newpot_np_
from py_np.newpot_jax import newpot, singlet
from py_np.singlet import singlet as singlet_np_
from scipy import constants, optimize

# config.update("jax_debug_nans", True)
config.update("jax_enable_x64", True)
AU_TO_INVCM = constants.value("hartree-inverse meter relationship") / 100

newpot_np = newpot_np_
singlet_np = lambda *arg: singlet_np_(*arg, 0)[0]

newpot_jax = jax.vmap(newpot, in_axes=(0, 0, 0, None))
singlet_jax = jax.jit(
    jax.vmap(lambda *args: singlet(*args, 0)[0], in_axes=(0, 0, 0, None))
)

newpot_f = jax.jit(jax.vmap(poten_f, in_axes=0))


def read_data():
    filename = "H3PLUS_BOE_plus_DBOC_plus_DIPOLE.txt"
    r_data = []
    pot_data = []
    with open(filename, "r", encoding="utf-8") as fl:
        for i, line in enumerate(fl):
            if i == 0:
                continue
            w = line.split()
            r_data.append([float(elem) for elem in w[2:5]])
            pot_data.append(float(w[5]))
    r_data = jnp.array(r_data, dtype=np.float64)
    pot_data = np.array(pot_data)
    return r_data, pot_data


def test_jax_pes():

    # read datafile
    r_data, pot_data = read_data()

    print("find minimum of Fortran wrapper potential")
    vmin = optimize.minimize(lambda x: _poten_f(np.array([x])), [1.0, 1.0, 1.0])
    r0 = vmin.x
    v0 = vmin.fun
    print("mininum of the potential:", r0, v0)

    v_jax = (newpot_jax(*r_data.T, coef3_x) - v0) * AU_TO_INVCM
    v_f = (newpot_f(r_data) - v0) * AU_TO_INVCM

    for i in range(100):
        v_np = (newpot_np(*r_data[i]) - v0) * AU_TO_INVCM
        print(
            i,
            " ".join("%12.8f" % elem for elem in r_data[i]),
            " ".join(
                "%12.6f" % elem
                for elem in (
                    v_jax[i],
                    v_np,
                    v_f[i],
                    v_jax[i] - v_np,
                    v_jax[i] - v_f[i],
                    pot_data[i],
                )
            ),
        )


class LinearExpansion(nn.Module):
    @nn.compact
    def __call__(self, r):
        c = self.param("_c", jax.nn.initializers.constant(coef3_x), (len(coef3_x),))
        v = newpot_jax(*r.T, c)
        return v


def fit_pes():

    def loss_func(params, r, y):
        return jnp.sqrt(jnp.mean(jnp.square(y - model.apply(params, r))))

    r_data, pot_data = read_data()
    r_data = r_data[:1000]
    pot_data = pot_data[:1000]

    # print(r_data.shape)
    # print(pot_data.shape)

    model = LinearExpansion()
    params = model.init(jax.random.PRNGKey(0), r_data)

    y = model.apply(params, r_data)
    l = loss_func(params, r_data, pot_data)
    print(y.shape)
    print(l)
    print(y[:100])
    g = jax.vmap(jax.jacrev(lambda x: model.apply(params, jnp.array([x]))), in_axes=0)(r_data)
    print(g.shape)
    print(g[:100])
    exit()

    optx = optax.adam(learning_rate=0.001)
    opt_state = optx.init(params)
    # loss_grad_fn = jax.jit(jax.value_and_grad(loss_func))
    loss_grad_fn = jax.value_and_grad(loss_func)

    # @jax.jit
    def train_step(carry, epoch):
        params, opt_state = carry
        loss_val, grad = loss_grad_fn(params, r_data, pot_data)
        updates, opt_state = optx.update(grad, opt_state)
        params = optax.apply_updates(params, updates)
        return (params, opt_state), loss_val

    # for i in range(100):
    #     no_epochs = 10
    #     carry, loss = jax.lax.scan(
    #         train_step, (params, opt_state), (np.arange(no_epochs))
    #     )
    #     params, opt_state = carry
    #     print(i * no_epochs, loss[-1])

    carry = (params, opt_state)
    for i in range(10000):
        carry, loss_val = train_step(carry, i)
        print(i, loss_val)


if __name__ == "__main__":
    fit_pes()
    # test_jax_pes()