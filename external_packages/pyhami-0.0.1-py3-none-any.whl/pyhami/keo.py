import numpy as np
from scipy import constants
import jax
from jax import numpy as jnp
from jax import config

config.update("jax_enable_x64", True)
import functools


G_to_invcm = (
    constants.value("Planck constant")
    * constants.value("Avogadro constant")
    * 1e16
    / (4.0 * np.pi**2 * constants.value("speed of light in vacuum"))
    * 1e5
)


eps = jnp.array(
    [
        [[int((i - j) * (j - k) * (k - i) * 0.5) for k in range(3)] for j in range(3)]
        for i in range(3)
    ],
    dtype=jnp.float64,
)


class Molecule_meta(type):
    def __init__(cls, *args, **kwargs):
        cls._masses = None

    @classmethod
    def internal_to_cartesian(cls, q):
        raise Exception(
            "Please specify internal-to-Cartesian transformation function:\n"
            + "\t'Molecule.internal_to_cartesian = function(q: jax.np.array(no. coords)) -> jax.np.array(no. atoms, 3)'"
        )

    @classmethod
    def cartesian_to_internal(cls, xyz):
        raise Exception(
            "Please specify internal-to-Cartesian transformation function:\n"
            + "\t'Molecule.internal_to_cartesian = function(q: jax.np.array(no. coords)) -> jax.np.array(no. atoms, 3)'"
        )

    @property
    def masses(cls):
        if cls._masses is None:
            raise Exception(
                f"Please specify atomic masses:\n\t'Molecule.masses: np.array(no. atoms)'"
            )
        return cls._masses

    @masses.setter
    def masses(cls, val):
        try:
            val.shape
        except AttributeError:
            raise Exception(f"Atomic masses must be a numpy array") from None
        cls._masses = val


class Molecule(metaclass=Molecule_meta):
    pass


def com(cart):
    @functools.wraps(cart)
    def wrapper_com(*args, **kwargs):
        xyz = cart(*args, **kwargs)
        masses = Molecule.masses
        com = jnp.dot(masses, xyz) / jnp.sum(masses)
        return xyz - com[jnp.newaxis, :]

    return wrapper_com


def eckart(r_ref):
    def _wrapper(cart):
        @functools.wraps(cart)
        def wrapper_eckart(*args, **kwargs):
            xyz = cart(*args, **kwargs)
            xyz_ref = cart(r_ref, **kwargs)
            masses = Molecule.masses
            
            #Correct for center of mass
            com = jnp.dot(masses, xyz) / jnp.sum(masses)
            com_ref = jnp.dot(masses, xyz_ref) / jnp.sum(masses)
            xyz -= com[None, :]
            xyz_ref -= com_ref[None, :]

            xyz_ma = xyz_ref - xyz
            xyz_pa = xyz_ref + xyz
            x_ma, y_ma, z_ma = xyz_ma.T
            x_pa, y_pa, z_pa = xyz_pa.T

            c11 = jnp.sum(masses * (x_ma**2 + y_ma**2 + z_ma**2))
            c12 = jnp.sum(masses * (y_pa * z_ma - y_ma * z_pa))
            c13 = jnp.sum(masses * (x_ma * z_pa - x_pa * z_ma))
            c14 = jnp.sum(masses * (x_pa * y_ma - x_ma * y_pa))
            c22 = jnp.sum(masses * (x_ma**2 + y_pa**2 + z_pa**2))
            c23 = jnp.sum(masses * (x_ma * y_ma - x_pa * y_pa))
            c24 = jnp.sum(masses * (x_ma * z_ma - x_pa * z_pa))
            c33 = jnp.sum(masses * (x_pa**2 + y_ma**2 + z_pa**2))
            c34 = jnp.sum(masses * (y_ma * z_ma - y_pa * z_pa))
            c44 = jnp.sum(masses * (x_pa**2 + y_pa**2 + z_ma**2))

            c = jnp.array(
                [
                    [c11, c12, c13, c14],
                    [c12, c22, c23, c24],
                    [c13, c23, c33, c34],
                    [c14, c24, c34, c44],
                ]
            )

            eigval, eigvec = jnp.linalg.eigh(c)
            quar = eigvec[:, 0]
            u = jnp.array(
                [
                    [
                        quar[0] ** 2 + quar[1] ** 2 - quar[2] ** 2 - quar[3] ** 2,
                        2 * (quar[1] * quar[2] + quar[0] * quar[3]),
                        2 * (quar[1] * quar[3] - quar[0] * quar[2]),
                    ],
                    [
                        2 * (quar[1] * quar[2] - quar[0] * quar[3]),
                        quar[0] ** 2 - quar[1] ** 2 + quar[2] ** 2 - quar[3] ** 2,
                        2 * (quar[2] * quar[3] + quar[0] * quar[1]),
                    ],
                    [
                        2 * (quar[1] * quar[3] + quar[0] * quar[2]),
                        2 * (quar[2] * quar[3] - quar[0] * quar[1]),
                        quar[0] ** 2 - quar[1] ** 2 - quar[2] ** 2 + quar[3] ** 2,
                    ],
                ]
            )
            return jnp.dot(xyz, u.T)

        return wrapper_eckart

    return _wrapper


@jax.jit
def gmat(q):
    xyz_g = jax.jacfwd(Molecule.internal_to_cartesian)(q)
    tvib = xyz_g
    xyz = Molecule.internal_to_cartesian(q)
    natoms = xyz.shape[0]
    trot = jnp.transpose(jnp.dot(eps, xyz.T), (2, 0, 1))
    ttra = jnp.array([jnp.eye(3, dtype=jnp.float64) for _ in range(natoms)])
    tvec = jnp.concatenate((tvib, trot, ttra), axis=2)
    masses_sq = np.array([np.sqrt(Molecule.masses[i]) for i in range(natoms)])
    tvec = tvec * masses_sq[:, jnp.newaxis, jnp.newaxis]
    tvec = jnp.reshape(tvec, (natoms * 3, len(q) + 6))
    return jnp.dot(tvec.T, tvec)


# @functools.partial(jax.jit, static_argnums=(0,1,))
def Gmat_s(q):
    xyz = Molecule.internal_to_cartesian(q)
    jac = jax.jacfwd(Molecule.cartesian_to_internal)(xyz)
    return (
        jnp.einsum("kia,lia,i->kl", jac, jac, 1 / Molecule.masses, optimize="optimal")
        * G_to_invcm
    )


batch_Gmat_s = jax.jit(jax.vmap(Gmat_s, in_axes=0))


@jax.jit
def Gmat(q):
    return jnp.linalg.inv(gmat(q)) * G_to_invcm


batch_Gmat = jax.jit(jax.vmap(Gmat, in_axes=0))


@jax.jit
def Gmat_s(q):
    xyz = Molecule.internal_to_cartesian(q)
    jac = jax.jacfwd(Molecule.cartesian_to_internal)(xyz)
    return (
        jnp.einsum("kia,lia,i->kl", jac, jac, 1 / Molecule.masses, optimize="optimal")
        * G_to_invcm
    )


batch_Gmat_s = jax.jit(jax.vmap(Gmat_s, in_axes=0))


@jax.jit
def dGmat(q):
    return jax.jacfwd(Gmat)(q)


batch_dGmat = jax.jit(jax.vmap(dGmat, in_axes=0))


@jax.jit
def Detgmat(q):
    nq = len(q)
    return jnp.linalg.det(gmat(q)[: nq + 3, : nq + 3])


@jax.jit
def dDetgmat(q):
    return jax.grad(Detgmat)(q)


@jax.jit
def hDetgmat(q):
    # return jax.jacfwd(jax.jacrev(Detgmat))(q)
    return jax.jacfwd(jax.jacfwd(Detgmat))(q)


@jax.jit
def pseudo(q):
    nq = len(q)
    G = Gmat(q)[:nq, :nq]
    dG = dGmat(q)[:nq, :nq, :]
    dG = jnp.transpose(dG, (0, 2, 1))
    det = Detgmat(q)
    det2 = det * det
    ddet = dDetgmat(q)
    hdet = hDetgmat(q)
    pseudo1 = (jnp.dot(ddet, jnp.dot(G, ddet))) / det2
    pseudo2 = (jnp.sum(jnp.diag(jnp.dot(dG, ddet))) + jnp.sum(G * hdet)) / det
    return (-3 * pseudo1 + 4 * pseudo2) / 32.0


batch_pseudo = jax.jit(jax.vmap(pseudo, in_axes=0))
