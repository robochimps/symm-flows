import numpy as np
from scipy import constants
import jax
from jax import numpy as jnp
from jax.config import config
config.update("jax_enable_x64", True)
import functools


G_to_invcm = constants.value('Planck constant') * constants.value('Avogadro constant') \
           * 1e16 / (4.0 * np.pi**2 * constants.value('speed of light in vacuum')) * 1e5


eps = jnp.array([[[ int((i - j) * (j - k) * (k - i) * 0.5)
                    for k in range(3) ]
                    for j in range(3) ]
                    for i in range(3) ], dtype=jnp.float64)


class Molecule_meta(type):
    def __init__(cls, *args, **kwargs):
        cls._masses = None
    @classmethod
    def internal_to_cartesian(cls, q):
        raise Exception("Please specify internal-to-Cartesian transformation function:\n" + \
            "\t'Molecule.internal_to_cartesian = function(q: jax.np.array(no. coords)) -> jax.np.array(no. atoms, 3)'")
    @property
    def masses(cls):
        if cls._masses is None:
            raise Exception(f"Please specify atomic masses:\n\t'Molecule.masses: np.array(no. atoms)'")
        return cls._masses
    @masses.setter
    def masses(cls, val):
        try:
            val.shape
        except AttributeError:
            raise Exception(f"Atomic masses must be a numpy array") from None
        cls._masses = val


class Molecule(metaclass=Molecule_meta):
    pass


def com(cart):
    @functools.wraps(cart)
    def wrapper_com(*args, **kwargs):
        xyz = cart(*args, **kwargs)
        masses = Molecule.masses
        com = jnp.dot(masses, xyz) / jnp.sum(masses)
        return xyz - com[jnp.newaxis, :]
    return wrapper_com


@jax.jit
def Gmat(q):
    m0, m1, m2 = Molecule.masses
    r1, r2, theta = q 
    fm = -1*(m1*m2*r1**2*(m0+m1+m2) + m0*r2**2*(m1+m2)**2)/(4*m0*m1*m2*r1**2*r2**2*(m1+m2))

    G = jnp.diag(jnp.array([(1/m1 + 1/m2)*jnp.sin(theta)*0.5, (m0+m1+m2)*jnp.sin(theta)/(m0*(m1+m2))*.5, -2*fm*jnp.sin(theta)]))
    return G * G_to_invcm

batch_Gmat = jax.jit(jax.vmap(Gmat, in_axes=0))

@jax.jit
def pseudo(q):
    m0, m1, m2 = Molecule.masses 
    r1, r2, theta = q 
    fm = -1*(m1*m2*r1**2*(m0+m1+m2) + m0*r2**2*(m1+m2)**2)/(4*m0*m1*m2*r1**2*r2**2*(m1+m2))
    return fm*jnp.sin(theta)*G_to_invcm

batch_pseudo = jax.jit(jax.vmap(pseudo, in_axes=0))

@jax.jit
def gsmall(q):
    m0, m1, m2 = Molecule.masses 
    r1, r2, theta = q 
    fm = -1*(m1*m2*r1**2*(m0+m1+m2) + m0*r2**2*(m1+m2)**2)/(4*m0*m1*m2*r1**2*r2**2*(m1+m2))
    return jnp.array([0., 0., -fm*jnp.cos(theta)])*G_to_invcm

batch_gsmall = jax.jit(jax.vmap(gsmall, in_axes=0))

