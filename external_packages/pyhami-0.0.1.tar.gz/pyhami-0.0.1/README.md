# pyhami
Python module for molecular kinetic energy operators and potential energy surfaces.

## Installation
You need to have meson and ninja installed. This can be done __via__

```console
$ pip install meson-python ninja
```

To install pyhami run:

Run
```console

$  meson setup builddir --prefix=$HOME/.local  # For user with no sudo rights.
$  meson setup --reconfigure builddir # use the option --reconfigure if you already have a build
  
$  meson compile -C builddir

$  meson install -C builddir
```
Run 

```console
$ bash installer.sh
```

## Authors and acknowledgment

Álvaro Fernández Corral, Yahya Saleh, Emil Vogt, Andrey Yachmenev.

## License

See [License](https://github.com/robochimps/pyhami/blob/main/LICENSE)


# Document your code

Use sphinx-type docstrings, likely numpydoc is a good format for starters, to
document all code. See https://realpython.com/documenting-python-code and
https://numpydoc.readthedocs.io/en/latest/format.html for an introduction,
